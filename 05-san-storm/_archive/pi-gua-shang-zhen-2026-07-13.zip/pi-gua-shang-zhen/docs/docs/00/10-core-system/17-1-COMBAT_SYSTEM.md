# 战斗系统

**文档版本**：v2.3.1  
**最后复盘**：2026-07-09（v2.3.1：反击档差 3 档 **×0.24**、4 档 **×0.20** — common 反击 legendary **13%**、反击 core ≈10%）  
**状态**：已实装（战术格手动/自动 · 伤害公式 · 士气 · **战后评分权威** · **战斗表现层**）

---

## 0. 关联文档与系统索引

| 主题 | 文档 | 关系 |
|------|------|------|
| **阵型**（首回合 Buff · 整体移动/攻击） | [17-2-FORMATION_SYSTEM.md](./17-2-FORMATION_SYSTEM.md) | 伤害链第 4.5 / 5.5 步；**强关联** |
| 攻城 / 城防 | [17-4-SIEGE_SYSTEM.md](../../01-jun-exploration/10-core-system/17-4-SIEGE_SYSTEM.md)、[13-2-CITY_DEFENSE_SYSTEM.md](../../01-jun-exploration/10-core-system/13-2-CITY_DEFENSE_SYSTEM.md) | 服务端推演共用公式 |
| 部队配置 · 克制 · 适应 | [22-1-TROOP_SYSTEM.md](../20-data-layer/22-1-TROOP_SYSTEM.md) | `troopType`、`*Counter`、`*Adapt`、`troopWeight` |
| 将领性格 · 士气初值 · 残影 | [21-1-CHARACTER_SYSTEM.md](../20-data-layer/21-1-CHARACTER_SYSTEM.md) §6 · §8.3 | `trait` / `trait_modifier` · `characterEchoSlots` |
| 官职兵种加成 | [12-1-POSITION_SYSTEM.md](./12-1-POSITION_SYSTEM.md) | `positionBonuses` |
| 战报归档 | [18-1-BATTLE_REPORT_SYSTEM.md](../../01-jun-exploration/10-core-system/18-1-BATTLE_REPORT_SYSTEM.md) | 存 `rewards.battleScore` / `scoreDetails` |
| **战后评分（权威）** | 本文 **§9** | `battleScoreSystem.js` / `battleScore.cjs` |
| 事件惩罚战 | [14-1-EVENT_SYSTEM.md](../../01-jun-exploration/10-core-system/14-1-EVENT_SYSTEM.md) | `EventBattleArena` |
| 匪寨 / 小型 PVE | [17-7-BANDIT_SYSTEM.md](../../04-challenge-mode/17-7-BANDIT_SYSTEM.md) | `pve_bandit` |
| 技能被动/主动 | `shared/utils/skillPhase1Passive.js` 等 | 命中/暴击/减伤/阶段技 |
| 战术/战役壳层 | [31-5-EVENT_VS_CAMPAIGN_BATTLE_ARCHITECTURE.md](../../01-jun-exploration/30-frontend/31-5-EVENT_VS_CAMPAIGN_BATTLE_ARCHITECTURE.md) | `SmallMapBattle` / `LargeMapBattle` |

**公式单源（客户端）**：`game/src/systems/combatSystem.js` · `calcDamage` / `estimateDamage` / `rollCritDodge`  
**服务端对齐**：`backend/lib/siegeCombatCore.cjs`（攻城 NPC 推演须与上式同步）

---

## 1. 功能概述

战斗系统驱动 **战术格回合制** 地图战：玩家在 **8×10 小型图**（探索/事件/匪寨/攻城等）或 **大型战役图** 上移动、普攻、施技，直至一方全灭或达成回合胜负条件。

| 维度 | 说明 |
|------|------|
| 核心循环 | 速度排序 → 单部队行动（手动或 AI）→ 命中/暴击/伤害 → 歼 stack 士气联动 |
| 伤害 | 三层：**基础公式** → **适应性修正** → **特殊加成（未实装）** |
| 与阵型 | 第 1 回合可组阵（见 **17-2**）；`_formationBuffs` 进入伤害链 |
| 非本文 | 旧版「按稀有度差固定 N 回合自动对砍」模拟器（`docs/tools/battle-simulator.cjs`）仅作数值实验，**非**现行战术图运行时 |

---

## 2. 战斗形态与入口

| 形态 | 壳层 | 说明 |
|------|------|------|
| 小型战术图 | `SmallMapBattle.jsx` | 探索惩罚战、攻城、匪寨、道路 PVP 等 |
| 大型战役图 | `LargeMapBattle.jsx` | 战役 DSL 地图 |
| 事件专用 | `EventBattleArena` | 探索事件惩罚战 |
| 手动 / 自动 | `useManualBattle` + `tacticalBattleEngine` | 手动：玩家逐步点选；自动：AI 决策 + 可选首回合阵型 |

**开战门闸**（全战斗通用，`validateMainLineupBattleGate`）：

| 条件 | 规则 |
|------|------|
| 上阵总兵力 | ≥ **200**（已装备部队 `current_troops` 合计） |
| 出征粮草 | 每支已装备部队 `ceil(当前兵力 / 20)` 之和；`players.food` 须足够 |

---

## 3. 伤害结算流水线

一次普攻（`calcDamage`）按序叠乘；**结算**另经 `rollCritDodge`（闪避则 0 伤；暴击 ×1.5）与 `troopDamageToCasualties`（精锐 `troopWeight>1` 折算兵力条扣减）。

| 步 | 环节 | 规则摘要 |
|----|------|----------|
| 0 | 磨损 | 传奇（`legendary`）部队 **`battleCount ≥ maxBattleCount`** 时攻/防 ×**0.8**（PVE 可用） |
| 1 | 单兵攻击 | 部队攻（配置 ÷10）+ 主属性×**6**（物理=武力；谋略线=智力） |
| 2 | 勇气 | × `(1 + 勇气/40)` |
| 3 | 当前兵力比 | 默认 `当前/最大`；`troopWeight>1` 时用 `(当前/最大)^0.8` |
| 4 | 士气攻 | 见 §5 表 |
| 4a | 性格攻 | 见 §6 表 |
| 4.5 | **阵型攻** | × `(1 + attackBonus)`，见 **17-2** |
| 4.6 | **残影 · 攻** | × `(1 + characterEchoAttackPct/100)`，见 **21-1 §8.3** |
| 5 | 防御减免 | 部队防（÷10）+ 统帅×5 + 武力×3；× 性格防强度；× 当前兵力比 → `def/(def+220)` × 士气防；**攻城**且 def 为守城方时 × `siegeCityDefenseMult`（= `cityDefense/100`，见 **13-1 §7**） |
| 5.5 | **阵型防** | 防御乘子 × `(1 + defenseBonus)`，上限 **0.9** |
| 5.6 | **残影 · 防** | 防御乘子 × `(1 + characterEchoDefensePct/100)` |
| 6 | 地形受击 | 树林 ×0.95；丘陵 ×0.90 |
| 7 | 等效兵力比 | 主动/反击共用 `clamp(max×weight 之比, 0.33, 3.0)`（**不再**对反击做低档软化抬高） |
| 7a | 反击基础乘子 | `strike:'counter'` 时 × **`COUNTER_STRIKE_DAMAGE_MULT`（0.95）** |
| 7b | **反击档差压制** | 反击方稀有度 **低于** 被反击方时，按档差叠乘 `COUNTER_LOWER_TIER_DAMAGE_MULT_BY_GAP`（见下表）；高档反击低档 **不加成** |
| 7c | 镜像对打 | 等效兵力相等时：主动 ×**1.10**；反击 ×**0.50** |
| 8 | 兵种克制 | × `atk[defTroopType + 'Counter']` |
| 9 | 地形适应 | × `atk[terrain + 'Adapt']`（攻击者所在格） |
| 10 | 官职兵种 | × `(1 + positionBonuses[{troopType}Bonus])` |
| 10.5 | 将领适性 | × `(1 + troop_affinity[{troopType}]/100)`（`troopAffinityCombat`） |
| 11 | 弓兵近战 | 弓兵打曼哈顿距离 ≤1：×**0.8** |
| — | 技能被动 | 阶段1/2 出站/入站乘子（见 shared 技能模块） |
| 12 | 随机浮动 | × **0.9～1.1**（`estimateDamage` **不含**此项） |

**精锐折算**：`troopWeight>1` 时，公式产出伤害再 **`round(raw/weight)`**，至少扣 **1** 兵力。  
**同档主动保底**：`troopDamageToCasualties` 在传入 **`attacker` + `strike:'normal'`** 且双方 **同稀有度** 时，取 **`max(扣减, ceil(maxTroops×20%))`**，满编同档约 **≤5 刀**；**反击不适用**此保底，避免反击被抬平。阵型/技能抬高公式伤害时仍可更快击杀。

| 常数 | 值 | 说明 |
|------|-----|------|
| `DEF_REDUCTION_DENOM` | **220** | `def/(def+K)` 分母；**K 越大穿透越高**（误改小会更磨） |
| `MIRROR_STRIKE_DAMAGE_MULT` | **1.10** | 等效兵力相等时主动一击 |
| `MIRROR_COUNTER_DAMAGE_MULT` | **0.50** | 等效兵力相等时反击（与同档主动联调至约 35%～50%） |
| `COUNTER_STRIKE_DAMAGE_MULT` | **0.95** | 所有反击在步 7a 叠乘 |
| `MIN_CASUALTY_PCT_OF_DEFENDER_MAX` | **0.20** | 仅 **同稀有度主动** 兵力条扣减下限 |
| `COUNTER_LOWER_TIER_DAMAGE_MULT_BY_GAP` | 见下表 | 反击方低于被反击方时按 **档差** 叠乘（`troopRarityCombat`） |

**反击档差叠乘表**（index = 反击方比被反击方低的档数；common=0 … core=4）：

| 档差 | 乘子 |
|------|------|
| 1 | ×0.44 |
| 2 | ×0.32 |
| 3 | ×0.24 |
| 4 | ×0.20 |

**设计目标（普攻基准）**：

| 场景 | 目标 |
|------|------|
| 同档满编互殴 | 主动约 **≤5 刀** 击杀（可略超） |
| 高档主动打低档 | 刀数明显少于同档互殴；低档主动打高档明显更慢 |
| 同档反击 | 约为当次主动的 **35%～50%** |
| 低档反击高档 | 约为当次主动的 **20%～35%**（档差越大越低） |
| 高档反击低档 | 不加成；可明显高于低档反击（见 §3.1 模拟表） |

### 3.1 数值校准基准（v2.3 模拟）

**条件**（与 `siegeCombatCore.cjs` 一致，无随机浮动 `rng=0.5→×1.0`）：平原、满编、士气 **70**、将领 **武力/统帅/勇气=7**、无阵型/技能/克制加成；步兵代表部队（冀州部曲 / rare 步 / 平原义军 / 丹阳兵）；`maxTroops` 取方案 B（**200 / 220 / 240 / 260**）。

| 对局 | 主动扣兵 | 约几刀 | 反击扣兵 | 反击/主动 |
|------|----------|--------|----------|-----------|
| common vs common | 44 | 4.6 | 19 | **43%** |
| rare vs rare | 44 | 5.0 | 19 | **43%** |
| epic vs epic | 48 | 5.0 | 19 | **40%** |
| legendary vs legendary | 52 | 5.0 | 19 | **37%** |
| rare → common | 44 | 4.6 | 15 | **34%** |
| epic → common | 48 | 4.2 | 10 | **21%** |
| legendary → common | 52 | 3.9 | 7 | **13%** |
| core → common（max **280**） | 56 | 3.6 | 5 | **9%** |
| core → common（配置 **200** · w1.2） | 48 | 4.2 | 5 | **10%** |
| common → epic | 33 | 7.3 | 45 | 136% |
| common → legendary | 30 | 8.7 | 49 | 163% |
| common → core | 28 | 10.0 | 53 | 189% |
| legendary → epic | 43 | 5.6 | 15 | **35%** |
| epic → rare | 43 | 5.1 | 15 | **35%** |
| rare → epic | 36 | 6.7 | 41 | 114% |

**读表说明**：

- 「A → B」= **A 主动一击 B**，「反击」= **B 反击 A**（扣 A 的兵力条）。
- **高档打低档**主动刀数：4.6 → 4.2 → 3.9（递减）；**低档打高档**：7.3～10 刀（明显偏慢）。
- **rare → common** 与同档 common 主动刀数接近：公式中 `combat×6` 主导、兵力比 1.1 ≈ 镜像 1.10，属数据/结构限制；跨 **2 档及以上** 差距已拉开。
- 复现：对 `backend/lib/siegeCombatCore.cjs` 调用 `calcDamageSeeded` + `troopDamageToCasualties`（须传 `attacker` / `strike`）。

---

## 4. 命中 · 闪避 · 暴击

| 项 | 公式 / 规则 |
|----|-------------|
| 基础闪避 | 防守运气 / **100** |
| 技能修正 | 阶段1 被动可 ±`dodgeRate` / `hitRate`（上限闪避 **45%**，命中预览下限 **5%**） |
| 命中预览 | `1 - 闪避 + hitRate`，上限 **99%** |
| 暴击率 | `(勇气 + 运气) / 80`，上限 **25%** |
| 暴击伤害 | × **1.5** |
| 判定顺序 | 先闪避 → 再暴击 → 普通命中 |

| 运气 | 基础闪避 |
|------|----------|
| 5 | 5% |
| 7 | 7% |
| 10 | 10% |

---

## 5. 士气

**存储**：整数 **0～120**；初始 `clamp(0, 120, 70 + trait_modifier×2)`（战役 DSL 可覆写基础值后再加性格修正）。

**战斗系数**（`getMoraleEffects`）：

| 士气点 | 攻击 | 防御 |
|--------|------|------|
| ≥80 | ×1.10 | ×1.05 |
| 60～79 | ×1.00 | ×1.00 |
| 40～59 | ×0.95 | ×0.90 |
| ＜40（崩溃） | ×0.90 | ×0.85；**本回合无法行动** |

**歼 stack 变动**（按将领去重）：击灭敌方 stack → 己方每个仍有兵将领 **+1**；己方 stack 被歼 → 该将领 **−10**（同将多 stack 同步）。常量：`commanderMorale.js` · `MORALE_DELTA_ON_ENEMY_STACK_KILLED` / `MORALE_DELTA_ON_OWN_STACK_ELIMINATED`。

**战后持久化**：战术结束经 `POST /api/battles` 的 `moraleUpdates` 写回 **`players.morale`（主公）** 与 **将领卡 `player_cards.morale`（character1/2）**；**不写部队卡**。实现：`buildMoralePersistUpdatesFromBattleTroops` · `battleService.applyBattlePostEffects`。

---

## 6. 将领性格（trait）

| 性格 | 修正值（士气用 ×2） | 伤害乘子 | 防守防御强度 |
|------|---------------------|----------|--------------|
| 勇猛 brave | +6 | ×1.06 | ×1.00 |
| 无惧 reckless | +8 | ×1.08 | ×**0.98** |
| 冷静 calm | +2 | ×1.02 | ×1.00 |
| 平凡 normal | 0 | ×1.00 | ×1.00 |
| 谨慎 cautious | −2 | ×0.98 | ×1.00 |
| 怯懦 timid | −6 | ×0.94 | ×1.00 |

单源：`shared/utils/characterTraitBonuses.js`（前后端攻城推演须一致）。

---

## 7. 兵力权重与配置规范

| 项 | 规则 |
|----|------|
| `troopWeight` | 默认 **1**；**>1** 启用凹曲线战损与伤害折算；现配置典型：**燕云十八** `3.5` |
| 等效兵力 | `maxTroops × troopWeight`（用于第 7 步 clamp，**不**随当前兵力变） |
| 标准满编（方案 B） | common **200** / rare **220** / epic **240** / legendary **260**（较稀有度每档 **+20**）；core 等特例见配置 |

详述：[22-1-TROOP_SYSTEM.md](../20-data-layer/22-1-TROOP_SYSTEM.md)。改表须同步 `battleScoreSystem.js` / `battleScore.cjs` 评分常数。

---

## 8. 战术回合与自动战斗

| 项 | 规则 |
|----|------|
| 回合顺序 | 按部队 `speed` 降序；阵型成员首回合可走 **17-2** 专用阶段 |
| 回合上限 | 地图可配 `maxRounds` 超时判负；`minRounds` 坚守胜利 |
| 自动战斗 | UI 标注 **2 银两/部队**（辅助面板）；AI 见 `battleTurnAi.js`（核心 `battleFlowManager.findBestMoveTarget`） |
| **陷阱规避（最高优先级）** | AI **优先级：避陷阱 > 攻击/接敌**。落脚点与全程路径都只在**无陷阱/火焰**格里选；接不到敌时宁可绕路或**原地等敌人靠近**，也不踩陷阱。**唯一例外**：道路被陷阱/障碍彻底卡死、不存在任何无陷阱路线抵达敌人射程时，才允许踩**最少**陷阱前进。判定见 `existsTrapFreeApproach` / 安全可达 `getReachableTilesSafe` / 无陷阱寻路 `findPathWithTrapBudget(maxTrapSteps=0)`。**阵型整体移动**（首回合 17-2、`formationGroupMove` / `computeFormationReachable`）同样**禁止**任何成员踏入陷阱/火焰格，与上规则一致。服务端 PVP 抽象自动对决（`pvpAutoDuelSim`）不含陷阱地形，故本规则仅作用于战术格自动战斗 |
| 自动阵型 | 第 1 回合且开关开启时 `autoSelectFormation` |
| 离屏超时 | 自动战斗中长时间无操作可按失败处理（`useAwayTimeout`） |
| 三阵营 | player / ally / enemy 共用同一 tooltip、属性与伤害管道（见战术 UI 一致性规则） |

---

## 9. 战后评分（权威）

单场战术战斗结束后的 **综合分** 与 **S～D 评级**，供战报展示、`player_statistics.total_battle_score` 累计、战役领奖倍率（**16-1**）、常驻榜场均（**18-4**）等复用。

**实现单源**（须保持同步）：

| 环境 | 文件 |
|------|------|
| 客户端 | `game/src/systems/battleScoreSystem.js` · `calculateBattleScore` |
| 服务端 | `backend/utils/battleScore.cjs` · 同名函数（攻城 PVP 权威推演等） |

**不适用**：地图探索连杀、拆建筑、开宝箱等旧草案项 — **未** 计入本公式。

### 9.1 损失比例

对每支参战部队（按 `faction` 区分敌我）：

| 项 | 规则 |
|----|------|
| 分母 | **`initialTroops`** 开战时实际兵力；缺省回退 `maxTroops` |
| 分子 | `initialTroops - currentTroops` |
| 比例 | `lostRatio = clamp(分子/分母, 0, 1)`；`initialTroops ≤ 0` 跳过 |

**歼敌/战损兵力**（`killTroops` / `lossTroops`）为人数合计，与 **±评分** 不同量纲，数值一般不相等。

### 9.2 歼敌分 · 战损分

| 阵营 | 条件 | 贡献 |
|------|------|------|
| `enemy` | `lostRatio > 0` | `+ round(KILL_SCORE[rarity] × lostRatio)` |
| `player` | `lostRatio > 0` | `+ round(LOSS_PENALTY[rarity] × lostRatio)` |

| 稀有度 | KILL_SCORE | LOSS_PENALTY |
|--------|------------|--------------|
| common | 200 | −300 |
| rare | 330 | −495 |
| epic | 460 | −690 |
| legendary | 600 | −900 |
| core | 800 | −1200 |

常量为 **固定表**，不从 `max_troops` 推导；`core=800` 与配置默认上限对齐。

**友军 `ally`**：仅 **`enemy`** 损兵计入歼敌分；`ally` 自身损兵 **不** 计战损分。

### 9.3 回合倍率

`baseScore = killScore + lossScore`；`normalScore = round(baseScore × TURN_MULTIPLIER[min(roundNum, 10)])`

| 回合 | 1 | 2 | 3 | 4 | 5 | 6 | 7～10 |
|------|---|---|---|---|---|---|-------|
| 倍率 | 1.4 | 1.3 | 1.2 | 1.15 | 1.1 | 1.05 | 1.0 |

### 9.4 保底（取 max）

| 步骤 | 名称 | 公式 |
|------|------|------|
| ② | 基础×回合 | `normalScore` |
| ③ | 战损保底 | `round(killScore × 0.3)` |
| ④ | 安慰保底 | 歼敌分为 0 且战损为负：`round(abs(lossScore) × 0.3)`，否则 0 |
| ⑤ | 择优 | `preSiegeScore = max(②, ③, ④)` |

胜方在歼敌高、己方战损也高时，仍可能因 ③ 抬分 — **预期行为**。

### 9.5 攻城积分倍率

`finalScore = round(preSiegeScore × scoreMultiplier)`；默认 `scoreMultiplier = 1`。

| 场景（`defenderType`） | 倍率 |
|------------------------|------|
| 玩家驻军 `player_garrison` | **1.5** |
| 披挂上阵 PVP `pvp_online` | **2.0** |
| 其它（NPC 守军等） | **1.0** |

详 **17-4**；战报 UI 第 ⑥ 步称「攻城积分倍率」或道路 PVP「PVP积分倍率」。

### 9.6 评级档

按 **`finalScore`**（倍率后）定档；`campaignService.gradeFromBattleScore` 与下表一致：

| 评级 | 分数 ≥ | 展示 | 奖励倍率 |
|------|--------|------|----------|
| S | 5000 | 完美！ | 2.0 |
| A | 3000 | 优秀！ | 1.5 |
| B | 1000 | 良好 | 1.2 |
| C | 500 | 及格 | 1.0 |
| D | 0 | 勉强 | 0.8 |

### 9.7 输出与下游

| 字段 | 用途 |
|------|------|
| `score` / `grade` / `gradeLabel` | 战报顶栏、战役 `bestScore` |
| `details`（`scoreDetails`） | 战报「完整计分步骤」· 纪念图 |
| 累计 | 战后 `total_battle_score += score`（见 **18-1**） |

---

## 10. 战斗表现（动画 · 特效）

**现行方案**：战术格上 **CSS 动画 + DOM 飘字 + 少量 PNG 帧**；**不**使用旧案 `Combat FX` sprite sheet（仓库 **无** 对应运行时引用；仅 wiki 静态资源目录留有素材副本）。

**编排层**：`game/src/battle/useBattleAnimations.js`（由 `tacticalBattleEngine` / `useBattleEngine` 调用）；样式 **`game/src/components/battle/BattleMap.css`**。战役大图复用同一套 class（`CampaignMapTile` · `.campaign-tile`）。

| 类别 | 表现 | 说明 |
|------|------|------|
| **近战普攻** | 攻方 `anim-atk-{left\|right\|up\|down}`；守方 `anim-hit` | 方向由格坐标差推算 |
| **暴击** | `anim-crit-hit` + 屏震 `anim-screen-shake` | 飘字 `dmg-num crit` |
| **闪避** | `anim-dodge` | 飘字 `MISS` · `dmg-num miss` |
| **远程** | DOM `.projectile` 沿直线平移 | 默认 emoji **`➤`**（弓兵 `weaponType` 以 `archer` 开头且射程 ≥2） |
| **伤害飘字** | `.dmg-num` 上浮 | 普攻白/暴击金；阶段4 物白/谋青；阶段3/5 治疗绿；灼烧/固伤等见 CSS |
| **主动技** | 全屏 `.skill-flash` + 格心 `.skill-name-pop` | 阶段3 治疗 / 阶段4·5 伤害共用；演示页 **`BattleAnimationDemoPage`** |
| **阵亡** | `anim-death` | 灰阶缩小淡出 |
| **着火格** | 格上 `.tile-fire-fx` 叠 **12** 帧 PNG | `public/assets/san_1_map/tile_3_effect/fire_frame_01～12.png`；`battleConstants.tacticalFireFrameUrl`；CSS `tile-fire-slot` 1.2s 循环 |
| **着火伤害** | 每回合末 `applyEndOfRoundFire` | 站在 `mapResult.cellFire` 格上单位扣当前兵力 **20%**（可触发阶段2 首击免疫） |

**数据**：`cellFire[y][x]` 由小型图生成器或战役 preset（`effect: fire`）写入；与移动力消耗 +2 联动见 `battleFlowManager.js`。

**跳过动画**：PVE 离开超时等场景 `setBattleAnimationSkipDelays(true)` — **只**跳过 `sleep` 等待，**不**改伤害结算。

---

## 11. 待实装

| 项 | 说明 |
|----|------|
| 势力 / 仙人加成 | `calcDamage` 第三部分预留 |
| 旧模拟器回合表 | 「跨级固定 2～5 回合」**非**战术图逻辑；**勿**与 §3.1 基准表混用 |
| 地图向评分 | 连杀、拆建筑、开宝箱等 — **未** 接入战后拼分 |
| **斩击 sprite sheet 特效** | 旧 `31-2-COMBAT_EFFECTS` 方案 **已废止**；若需新特效须单独立项 |

---

## 12. 实现落点

| 职责 | 路径 |
|------|------|
| 伤害 / 士气 / 命中 | `game/src/systems/combatSystem.js` |
| 反击稀有度档差 | `shared/utils/troopRarityCombat.js` · `.cjs` |
| 战术引擎 · 回合 | `game/src/battle/tacticalBattleEngine.js` |
| 手动操作 | `game/src/hooks/useManualBattle.js` |
| 动画 · 普攻/技能表现 | `game/src/battle/useBattleAnimations.js` · `BattleMap.css` |
| 格渲染 · 着火叠层 | `game/src/components/battle/BattleTile.jsx` · `battleConstants.js` |
| 士气歼杀 | `game/src/battle/commanderMorale.js` |
| 评分 | `game/src/systems/battleScoreSystem.js` · `backend/utils/battleScore.cjs` |
| 兵力上限 | `shared/utils/resolveTroopBattleCaps.js` |
| 开战门闸 | `game/src/utils/mainLineupTroops.js` |
| 小型图壳 | `game/src/components/battle/SmallMapBattle.jsx` |
| 攻城推演 | `backend/lib/siegeCombatCore.cjs` |
| 官职装配 | `shared/utils/positionCombatBonuses.cjs` |
| 将领残影 | `shared/utils/characterEchoCombat.cjs` · `.js` |
