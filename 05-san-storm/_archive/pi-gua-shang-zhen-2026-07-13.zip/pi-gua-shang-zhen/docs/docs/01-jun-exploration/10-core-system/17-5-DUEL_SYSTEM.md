# 玩家对决系统（PVP · 权威推演）

**文档版本**：v2.4.3  
**最后复盘**：2026-06-05（道路攻方裁定 UX、结算通用文案、`PvpTacticalBattleShell` 与 map-card 对齐）  
**状态**：**全阶段已实装**——第一阶段（攻城披挂 + 道路遭遇）+ **第二阶段 §12 战术对决 `pvp_tactical_duel`**（见 [17-5-2](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md)，步骤 8 邀战入口暂缓）均已落地；**真实两链（披挂/道路）底层推演已由 `runPvpAutoDuel` 迁移到 `runPvpTacticalDuel`**（见 [17-5-3](./17-5-3-DUEL_REAL_CHAIN_MIGRATION.md)，事件流回放、真实写回保留）。**§12.14 命名统一：前后端均已完成**（`runPvpAutoDuel`/`pvp/auto-duel/`、`PvpAutoDuelReplay`、`rewards.autoDuelBattleLog`；全库无 `skirmish`/`SiegeReplayMini` 代码标识符）。

---

## 0. 关联文档与系统索引

| 主题 | 文档 | 关系 |
|------|------|------|
| 战术棋盘战（手动） | [17-1-COMBAT_SYSTEM.md](./17-1-COMBAT_SYSTEM.md) | 小型图 ≥200 兵；**非**本文自动战 |
| 阵型 | [17-2-FORMATION_SYSTEM.md](./17-2-FORMATION_SYSTEM.md) | 自动对决入参含阵位加成 |
| 势力战事 | [17-3-WAR_SYSTEM.md](./17-3-WAR_SYSTEM.md) | 披挂须在 **active `wars_pvp`** 下成立 |
| 攻城流程 | [17-4-SIEGE_SYSTEM.md](./17-4-SIEGE_SYSTEM.md) | 队列命中披挂 → 本文 §4 |
| 城防 · 披挂开关 | [13-2-CITY_DEFENSE_SYSTEM.md](./13-2-CITY_DEFENSE_SYSTEM.md) | §5 披挂产品语义；战斗细节以本文为准 |
| 上阵编组 | [22-2-TROOP_LINEUP_SYSTEM.md](../../00/20-data-layer/22-2-TROOP_LINEUP_SYSTEM.md) | 双方 **`main_lineup`** 为推演单位来源 |
| 战略道路 · 占格触发 | [31-6-STRATEGIC_ROAD_MARCH.md](../30-frontend/31-6-STRATEGIC_ROAD_MARCH.md) | 行军/守门/遭遇登记；**不含**战斗推演条文 |
| 道路 API 契约 | [12-road-encounter-api.md](../../00/00-base/02-architecture-split/12-road-encounter-api.md) | HTTP 路径与幂等 |
| 战报 | [18-1-BATTLE_REPORT_SYSTEM.md](./18-1-BATTLE_REPORT_SYSTEM.md) | `pvp_field` / `pvp_defense` 等（底层均为 **自动对决** 推演） |
| 库表 | [60-tables-other.md](../../00/00-base/01-database-split/60-tables-other.md) §3.2.24 | `road_encounters`；[50-tables-battle.md](../../00/00-base/01-database-split/50-tables-battle.md) | `battles` |
| 架构索引 | [50-battle-system.md](../../00/00-base/02-architecture-split/50-battle-system.md) | 分层、**PVP 目录约定** §3.1 |
| 第二阶段（战术对决） | 本文 **§12**；**[17-5-2](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md)** | 房间、事件流、对决地图；**§12.14** 重命名 |
| 真实链战术化（披挂/道路迁移） | **[17-5-3](./17-5-3-DUEL_REAL_CHAIN_MIGRATION.md)** | 披挂/道路由 `runPvpAutoDuel` → `runPvpTacticalDuel`；保留真实写回（伤亡/老兵/士气/排行），事件流回放 |
| PvP 对决地图（策划 + 工程） | [../map-design/PVP_DUEL_MAP_RULES.md](../map-design/PVP_DUEL_MAP_RULES.md) | `rule_profile`、preset schema、生成工作流 |
| 第三阶段（同步手动棋盘） | 本文 **§12.11** | 在 §12 事件协议上扩展 `playerAction` |

---

## 1. 功能概述

### 1.1 演进阶段（总览）

| 阶段 | 名称 | 推演 | 客户端 | 状态 |
|------|------|------|--------|------|
| **一** | **自动对决**（`pvp_auto_duel`） | 服务端 **`runPvpAutoDuel`**：无格子走位（原 skirmish / 模拟演练） | **`PvpAutoDuelReplay`** 文本回放；`SmallMapBattle` 在 `skipSiegeResult` 下为演示壳 | **已实装** §3～§6 |
| **二** | **战术对决**（`pvp_tactical_duel`） | 服务端 **`runPvpTacticalDuel`**（方案 A）：8×10 走位、速度回合、自动 AI | 双方在线：**事件流**驱动格子动画；离线：战报 + 完整 replay | **已实装**（§12 / [17-5-2](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md)；步骤 8 邀战入口暂缓）；披挂/道路两链已迁此内核（[17-5-3](./17-5-3-DUEL_REAL_CHAIN_MIGRATION.md)） |
| **三** | 同步手动棋盘 | 在 §12 房间与事件流上增加 **双方指令**、回合锁 | 同图实时操作 | **规划** |

### 1.2 第一阶段（当前正文 §2～§10）

本文 **§2～§10** 描述第一阶段：双方各用 **上阵编组（`main_lineup`）**，由服务端 **自动对决（`pvp_auto_duel`）** 决胜负，客户端以 **观战式 BattleArena** + **简化回放（`PvpAutoDuelReplay`）** 呈现，**不以** 本地战术壳结果写库。

| 场景 | 触发 | 战果写回 |
|------|------|----------|
| **攻城 · 披挂上阵** | PVP 攻方队列命中 `pvp_online`（`garrison_slot = 0`） | `siege-resolve` → `pvpWarService.recordAttackerCitySiegeResult` |
| **战略道路 · 遭遇** | 敌对玩家同道路格、`road_encounters.fighting` | `encounter-authoritative-resolve` → `resolve-encounter` + `battles` |

**不在本文范围**：

- 驻地编组、NPC 批次：客户端小型图 + 单次战果 API（见 **17-4**、**13-2** §5.3）。
- 战术层手动对战（**17-1**）。
- **实时同步、手动操作的 3v3 战事预约对决**（原 v1 主将对决设想，见 §11）。

**产品取舍（已定稿）**：第一阶段 **不实现** 强实时手动 PVP；道路/披挂与 **同一自动对决推演** 同源。第二阶段起 **专用 PVP 模块与地图**，不与 PVE 战术壳混目录（见 **§12.10**）。**命名**与二阶段 `pvp_tactical_duel` 对称，见 **§12.14**。

---

## 2. 与战术战斗的边界

| 维度 | 本文（权威 **自动对决**） | 17-1 战术战 |
|------|------------------------|-------------|
| 地图 | 无格子走位；抽象接战线两格对射 | 8×10 棋盘、寻路、射程 |
| 伤害链 | `siegeCombatCore`（与棋盘战同源公式） | `combatSystem` / BattleArena 实时演算 |
| 胜负权威 | **仅** 服务端 **`runPvpAutoDuel`** | 客户端演算 + 战果 API（驻地/NPC） |
| 兵力门槛 | 上阵总兵力 ≥ **200**（开战门闸，与道路/攻城一致） | 同上，另耗出征粮草 |

披挂/道路 **不要求** 玩家进入可操作的战术回合；BattleArena 在 **`pvp_siege`** + **`skipSiegeResult` / `recordOnly`** 下为 **演示壳**，守方点「确定」亦为 **观战**，非接受对战。

---

## 3. 共用推演引擎（自动对决 · `pvp_auto_duel`）

> **命名**：原 `siegePvpSkirmish` / `runSiegePvpSkirmish` 已按 **§12.14** 重命名为 `runPvpAutoDuel`（`services/pvp/auto-duel/`）。
>
> **⚠️ 已迁移（[17-5-3](./17-5-3-DUEL_REAL_CHAIN_MIGRATION.md)）**：**披挂①/道路②两条真实链的底层推演已从 `runPvpAutoDuel` 切换为第二阶段战术内核 `runPvpTacticalDuel`**（含城防/地形、事件流回放），但 **写回/士气/老兵/战报/排行口径完全沿用本节描述**（适配器 `tacticalToAutoDuelResult` 还原为同形 `sim.*`）。本节 §3～§5 描述的「自动对决」语义仍为两链的**结算与口径基准**，且 `runPvpAutoDuel` 仍服务 **AI 征发军团**（§12.14.3）。

| 项 | 约定 |
|----|------|
| 管线标识 | **`pvp_auto_duel`**（与二阶段 **`pvp_tactical_duel`** 对称；**非** `battles.battle_type` 枚举值） |
| 核心函数 | **`runPvpAutoDuel(attackerNpcs, defenderNpcs, seed)`**（`pvp/auto-duel/pvpAutoDuelSim.js`；披挂/道路实际调用见 17-5-3 的 `runPvpTacticalDuel`） |
| 随机种子 | `hashSeed` 由业务 id + 双方 `player_id` 等拼接；**同输入必同结果** |
| 回合语义 | 与 BattleArena 一致：按速度排序行动；主动攻击后在反击射程内可 **反击** |
| 数值 | `calcDamageSeeded`、`rollCritDodgeSeeded`、`troopDamageToCasualties`（`siegeCombatCore.cjs`） |
| 单位来源 | `garrisonService.buildDefenseUnitsFromMainLineup` → `mapBuiltUnitsToSiegeNpcFormat` |
| 战后兵力 | 攻/守 **`player_cards`** 由权威伤亡写回（披挂：`applyAuthoritativePvpAutoDuel*Casualties`；道路：攻方 casualties + 守方 `defenderLineupTroopUpdates`） |

**道路与披挂唯一工程差异**：入口 service、锁键、写回表（`wars_pvp` / `road_encounters`）与战报 `battle_type` 枚举；**推演本体不分叉**。

---

## 4. 场景 A：攻城 · 披挂上阵

### 4.1 前置（与 17-4 / 13-2 对齐）

| 项 | 规则 |
|----|------|
| 战事 | 须有 **active `wars_pvp`**；披挂自动对决裁定服务无 `pvpWarId` 则拒绝（迁后 `pvpGarrisonAutoDuelResolveService`） |
| 槽位 | **`defenderGarrisonSlot === 0`**（披挂；锁键 `def\|{pvpWarId}\|{playerId}\|0`） |
| 挑战态 | `POST /api/pvp/challenge` 建立内存挑战；倒计时约 **10s** |
| 门闸 | `garrisonService.validateMainLineupBattleGateOnConn`（≥200 兵、出征粮草） |

### 4.2 流程（在线完整 UI；与道路 §5.2 对齐）

| 步骤 | 行为 |
|------|------|
| 1 | 攻方 `initiateAttackerCitySiege` 命中披挂 → 前端 `challenge` |
| 2 | 守方（**`WorldMap` 内**）轮询 **`GET /api/pvp/pending`** → **AncientModal** 遇袭（约 10s）；确定 → **`pvpDefenseWaiting`** 裁定等待 |
| 3 | 倒计时结束后攻方 **`POST /api/pvp/siege-resolve`**（`challengeId`） |
| 4 | 服务端 `doResolveAuthoritativeGarrisonAutoDuel` → 战术内核推演 → 写战果、**攻守各一条战报**、伤亡、`eventReplay` 房间（best-effort） |
| 5 | 攻方 **`WorldMap`**：最短裁定 UI → **`PvpTacticalBattleShell`**（无房间则 **`PvpAutoDuelReplay`**）→ **`StrategicSettlementCard`** |
| 6 | 守方 **`WorldMap`**：轮询 **`GET …/siege-outcome`** → 同源战术回放壳 → **`StrategicSettlementCard`**（`mapRoadEncounterOutcomeToSettlementProps`，守方视角） |

未点确定、已关遇袭弹窗、或已离开大地图 Tab 的守方：**服务端照样结算**；战果与战报照常入库，可事后在通信面板「战报」查看（含 `rewards.eventReplay` 回放入口）。**不保证**客户端仍弹出遇袭 / 观战 / 结算层——见 **§4.4**。

### 4.3 战报与评分

| 项 | 约定 |
|----|------|
| 条数 | 攻守 **各一条** 自动对决战报 |
| 守方日志 | `buildDefenderPvpAutoDuelBattleLog`（`[攻方]` / `[守军]` 行） |
| 积分倍率 | `SIEGE_PVP_ONLINE_SCORE_MULT`（相对 NPC 档 ×2，见 **13-2** §8） |
| `battle_type` | 攻方 **`pvp_siege`**、守方 **`pvp_defense`**；写库经 `battleService`；守方 `rewards.autoDuelBattleLog` 保留推演原文供简化回放 |

### 4.4 守方 UI 宿主与离线取舍（与道路 §5.3 对照，已定稿）

| 项 | 道路遭遇守方 | 披挂上阵守方 |
|----|-------------|-------------|
| React 宿主 | **`GamePage` 常驻** `RoadEncounterDefenseRoot.jsx` | **`WorldMap.jsx`**（`usePvpDefenseAlertPoll` + `usePvpSiegeAdjudication`） |
| 离开大地图 Tab | 仍轮询遇袭 / 裁定 / 回放 / 结算 | **`WorldMap` 卸载后不保证**继续弹出上述 UI |
| 产品取舍 | 道路交战须占格禁离，守方宜在线感知战事 | 披挂典型为「挂机守城」：玩家可下线、切 Tab、关闭客户端；**不要求**与道路守方一样提升到 `GamePage` 常驻层 |
| 权威底线 | 攻方 `encounter-authoritative-resolve` 后照样写战果 + 战报 | 攻方 `siege-resolve` 后照样写 **`wars_pvp` 战果**、兵力伤亡、**攻守各一条战报** |
| 在线完整体验 | 与 §5.2 攻方对称：战术回放壳 → `StrategicSettlementCard` | 与道路守方 **同一套共享组件**；仅 **挂载层级** 不同 |
| 事后补看 | 通信「战报」+ `rewards.eventReplay.roomId` | 同上；离线或错过弹窗时以战报为准 |

**结论**：披挂守方 UI 挂在 `WorldMap` 是**有意为之**，不是待修缺陷；验收以「触发战斗后战报与写回正确」为准，不以「守方必须在线看完回放」为准。

---

## 5. 场景 B：战略道路遭遇

战略层触发、占格锁、禁离格、战后退让与 **`road_intercept`** 开关见 **[31-6](../30-frontend/31-6-STRATEGIC_ROAD_MARCH.md)** §3～§5、§6～§9。本节只述 **战斗链**。

### 5.1 实例与门闸

| 项 | 约定 |
|----|------|
| 登记 | `road_encounters.status = fighting`；`gatekeeper_player_id` 仅当守方 **`road_intercept=1`** |
| 双方门闸 | 与披挂相同 **`validateMainLineupBattleGateOnConn`**；任一方不满足 → **退让**至最近己方城锚（不写遭遇）；移动方未过门闸见 **31-6** §4.2 |
| 攻方 API | **`POST …/road/encounter-authoritative-resolve`**（仅进攻方） |
| 守方轮询 | **`GET …/road/encounter-authoritative-outcome`** → 读 **`authoritative_resolution_json`** |

### 5.2 流程（与披挂对齐）

| 角色 | 步骤 |
|------|------|
| 守方 | `RoadEncounterDefenseRoot` 轮询 **`pending-encounter`** → 遇袭弹窗 → 确定后等待攻方裁定（约 **10s** 自动开战） |
| 攻方 | `road/move` 登记遭遇后 → **单一**「道路遭遇」弹窗（**约 10s** 倒计时 + 裁定说明）；自动或点 **「立即开战」** → **`encounter-authoritative-resolve`**（**无**「道路裁定中」中间弹窗） |
| 攻方裁定 | API 返回后 **直接** 挂事件回放 **`PvpTacticalBattleShell`**（无房间则 **`PvpAutoDuelReplay`**）→ **`StrategicSettlementCard`**（`WorldMapBattlePortal`；**通用**战斗结算文案，无「攻城」专称） |
| 守方裁定 | 轮询 **`encounter-authoritative-outcome`**（败方含 **`defeatRetreatNotice`**）→ 同源战术回放壳 → **`StrategicSettlementCard`**（道路 PVP **不** 展示 NPC 守军行） |
| 战后 | 权威裁定内已 **`resolved`** + 写战报；败方 **`applyFactionPlayerRoadRetreat`** + `road_client_notice`；结算卡 **确定** 后显式弹退让提示（`enqueueRoadGateNotice`，与轮询互补）；守门方战败 **`road_intercept=0`** |

### 5.3 禁离格与弹窗互斥

| 项 | 约定 |
|----|------|
| `fighting` 期间 | 攻防任一方 **`road/move`** 路径离开交战格 → **409** |
| 攻城优先 | **`GET /api/pvp/pending`** 占弹窗时，道路遇袭在 **`worldMapOverlayRefs`** 上排队 |
| 底栏 busy | `GamePage` **`eventBusy`** 合并道路守方层（遇袭 / 裁定 / 回放 / 评分） |

### 5.4 战报

| 项 | 约定 |
|----|------|
| `battle_type` | **`pvp_field`**（平原 PVP）；`war_id` **NULL** |
| 关联 | `road_encounters.battle_id` → `battles` |
| 详情 | **02 §2.1.2（4）**、**12-road-encounter-api** §3 |

---

## 6. 共用客户端表现

| 组件 | 职责 |
|------|------|
| **`BattleArena`** | `battleType: pvp_siege`；`skipSiegeResult` / `recordOnly`；**不**由守方提交道路 battle-result |
| **`PvpAutoDuelReplay`**（迁前 `SiegeReplayMini`） | 权威裁定后的全屏简化回放；道路守方与攻城攻方 **同组件** |
| **`StrategicSettlementCard`** | 道路 / 披挂 PVP 攻/守方战后 **统一**深色「战斗结算」；`road_encounter` / `pvp_online` **隐藏** NPC 守军累计行；奖励/掉落/战报入口为 **通用**文言（无「攻城战后」等专称） |
| **`PvpTacticalBattleShell`** | 事件流战术回放；倍速/关闭控件与 **`BattleLog`** 宽度 **对齐 `.map-card` 外缘**（与 `SmallMapBattle` 同 `layoutWidth` + `ResizeObserver` 口径） |
| **`AncientModal`** | 遇袭倒计时；道路须 **`invokeOnCloseAfterConfirm={false}`**，确定 **await** 后再关，避免与拉 battle 竞态 |
| **`buildSiegeUnits.js`** | `pvp_siege` / `pve_siege` 预置阵容组装（非 event 随机模式） |

**攻方道路 / 披挂裁定宿主**：`WorldMap.jsx`（`authoritativeReplayOverlay`）。  
**守方道路宿主**：`RoadEncounterDefenseRoot.jsx` + `RoadDefenseFrictionContext.jsx`（**GamePage 常驻**；大地图 Tab 卸载时仍轮询）。  
**守方披挂宿主**：`WorldMap.jsx`（**仅大地图 Tab**；离线或离 Tab 不保证弹 UI，战报仍生成——**§4.4**）。

---

## 7. API 摘要

| 场景 | 方法 | 路径 |
|------|------|------|
| 披挂挑战 | POST | `/api/pvp/challenge` |
| 披挂待战 | GET | `/api/pvp/pending` |
| 披挂权威裁定 | POST | `/api/pvp/siege-resolve` |
| 道路待战 | GET | `/api/players/:playerId/road/pending-encounter` |
| 道路开战载荷 | GET | `/api/players/:playerId/road/encounter-battle`（`spectator=1` 守方） |
| 道路权威裁定 | POST | `/api/players/:playerId/road/encounter-authoritative-resolve` |
| 道路裁定结果 | GET | `/api/players/:playerId/road/encounter-authoritative-outcome` |
| 道路战后解锁 | POST | `/api/players/:playerId/road/resolve-encounter` |

完整契约、错误码与幂等见 **12-road-encounter-api**；披挂挑战字段见 **13-2** §10、`pvpService`。

---

## 8. 实现落点（第一阶段 · 迁移前快照）

> **§12.10** 起，下列 **自动对决** / 披挂 / 道路裁定相关实现 **迁入 `backend/services/pvp/`、`game/src/pvp/`**，并执行 **§12.14 重命名**。第二阶段完成后删除已无用的「演示壳」路径。共享公式仍用 `siegeCombatCore.cjs` / `combatSystem.js`。

| 职责 | 当前文件（迁移 + 重命名见 §12.14） |
|------|-----------------------------------|
| 自动对决推演 | `siegePvpSkirmish.js` → **`pvp/auto-duel/pvpAutoDuelSim.js`** |
| 披挂裁定 | `siegePvpResolveService.js` → **`pvp/auto-duel/pvpGarrisonAutoDuelResolveService.js`** |
| 道路遭遇裁定 | `roadEncounterService.js` 内推演段 → 调 **`runPvpAutoDuel`**（文件可留 `road/`，**禁止** 内嵌推演循环） |
| 编组 → 战斗单位 | `garrisonService`（**共享**）；PvP 仅 **`pvp/lineupSnapshot.js`** 包装快照 |
| 道路退让 | `roadBattleRetreatPlacement.js`（战略层，可留原处） |
| 战报日志 | `siegeDefenseBattleLog.js` → **`pvp/auto-duel/pvpAutoDuelBattleLog.js`** |
| 评分 | `shared/utils/battleScore.cjs`（**共享**） |
| 攻城 / 道路 UI | `WorldMap.jsx`、`RoadEncounterDefenseRoot.jsx`（战略入口，调用 **`@/pvp/`**） |
| 自动对决回放 | `SiegeReplayMini.jsx` → **`game/src/pvp/auto-duel/PvpAutoDuelReplay.jsx`** |
| 结算弹窗 | `PvpDefenseOutcomeModal.jsx` → **`game/src/pvp/shared/`** |

---

## 9. 并发与幂等

| 项 | 约定 |
|----|------|
| 披挂 | 自动对决裁定服务内 **`resolvingPromises`** 防双次结算 |
| 道路 | `authoritativeRoadResolveLocks` 按 `encounterId` 串行 |
| 幂等 | 已 `resolved` 的道路遭遇再请求裁定 → 返回 **`authoritative_resolution_json`**（`idempotent: true`） |
| 挑战态 | `pvpService` 为 **单进程内存**；多实例部署前须外置存储（见 **50-battle-system**） |

---

## 10. 与驻地 / NPC 对照（速查）

| 防守档 / 场景 | 推演位置 | 客户端是否以本地战术结果为准 |
|-------------|----------|------------------------------|
| 披挂 `pvp_online` | 服务端 **`runPvpTacticalDuel`**（17-5-3 迁移；口径同自动对决） | **否** |
| 道路遭遇 | 服务端 **`runPvpTacticalDuel`**（同源；17-5-3） | **否** |
| 战术切磋 / 对决（二阶段） | 服务端 **`runPvpTacticalDuel`** | **否**（仅播事件） |
| 驻地 `player_garrison` | 客户端 SmallMapBattle（PVE） | **是**（单次战果 API 校验） |
| NPC | 客户端 SmallMapBattle（PVE） | **是** |

---

## 11. 战事预约「主将对决」（3v3 · **待实装**）

| 项 | 说明 |
|----|------|
| 状态 | **尚未实装**；`wars_pvp.duel_history` JSON 列已预留 |
| 发起 | **攻方** 发起 **约战**；**1 小时准备期** 后执行（非即时；与 11-3 阶段窗 **独立**） |
| 准备 | 守方在准备期内 **选派 3 名** 应战玩家并排兵 |
| 赛制 | 双方各 **3 人**，**1v1 三局**（A1↔B1、A2↔B2、A3↔B3）；每局 **独立** 结算 |
| 士气 | **胜方势力 +5、败方 −5**（**零和**，与 17-3 §7.4 战事士气同源写回）；单轮最多 **±15** |
| 缺员 | 应派 3 人但 **未满员** 的槽位 **按单局判负**（该槽 **+5/−5** 仍执行） |
| 未应战 | 已指派但未出战的个人对局 **判负**（同上，按 **单局** 计） |
| 文档 | 终局并行条件见 [17-3 §7.4](./17-3-WAR_SYSTEM.md)；**不得**与自动对决 / 战术对决混为同一推演管线 |

> 原 v1.0 长文（实时同步手动 3v3、士气 ±10）**已由本文 v2.0.0 取代**；**第三阶段**手动同步棋盘见 **§12.11**，与 **`pvp_auto_duel` / `pvp_tactical_duel`** 分轨。

---

## 12. 第二阶段：战术自动对决（**已实装** · 详见 [17-5-2](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md)）

### 12.1 目标与原则

| 项 | 约定 |
|----|------|
| 权威 | **仅服务端** **`runPvpTacticalDuel`** 产出胜负；客户端 **只播放事件**，不写库 |
| 切磋＝模拟游玩 | **产品决策 2026-06-03**：友谊「阵前切磋」为 **模拟游玩**，**不**写回 `player_cards` 兵力伤亡、**不**进老兵 `battle_count`、**不**计分（`total_battle_score`）/奖励；仅产出 **双方战报 + 事件流** 供回看（`battles.rewards.battleScore` 仅展示）。如未来需真实兵力成本，再接 casualties 写回（须与老兵 `battle_count` 拆离） |
| 方案 | **方案 A（已定稿）**：从 `tacticalBattleEngine` 剥离 **无 DOM / 无 sleep** 的纯推演内核，供 Node 与浏览器共用；为 **第三阶段** 手动指令预留同一 `roomId` + 事件表 |
| 与 PVE | **禁止** 在 `SmallMapBattle` / `useWorldMapStrategicBattles` 的 PVE 分支上叠 PVP 逻辑；PVP 专用目录与壳层（**§12.10**） |
| 与第一阶段 | 道路 / 披挂可 **继续自动对决** 直至产品决定切换；第二阶段先以 **独立入口**（如「阵前切磋」）验证，**不强制** 替换战略遭遇 |

### 12.2 专用对决地图（8×10 · 已合意）

| 项 | 约定 |
|----|------|
| 算法 | **`generateSmallMap`**（31-1 §4）+ **`applyPvpDuelRules`**（`pvpDuelMapGenerator`）；详见 **[PVP_DUEL_MAP_RULES.md](../map-design/PVP_DUEL_MAP_RULES.md)** |
| 策划稿 | [../map-design/PVP_DUEL_MAP_RULES.md](../map-design/PVP_DUEL_MAP_RULES.md) · `rule_profile` 模板 |
| 固化 | 管理员页 **「对决地图」** 预览满意后 → **`shared/data/pvp-duel/*.preset.json`** |
| 战中抽图 | 从 catalog **`DUEL_MAP_PRESET_IDS`**（仓库已有 id）**随机 1 张**；**不写死**每 profile 张数 |
| 公平性 | **非镜像**：上下（deployA/B）在规则内 **各自随机**、同类元素 **数量相近**（如各 3 巨石），禁贴边列等由 preset 约束 |
| PVE 对象 | **`chest` / `trap` 禁止**（竞技向默认） |
| 房间 API | `duelMapId` + 固化内嵌 `seed` + `lineupSnapshots`；`canonical` 攻/守半场见 preset |
| 管理入口 | 游戏主页卡片 → `/pvp-duel-map-manager`（对齐战役地图管理页，**待实装**） |

**不在 `game/src/data/texts/` 记录规则**；运行时只读 **shared** preset + 生成器。

### 12.3 房间与状态机

建议持久化表 **`pvp_tactical_rooms`**（或 Redis + DB 快照）；多实例部署 **必须** 外置（取代单进程 `pvpService` 内存挑战，见 §9）。

| 状态 | 含义 |
|------|------|
| `invited` | 邀战已发，待应战 / 倒计时 |
| `both_ready` | 双方门闸通过（≥200 兵、粮草），阵容快照已锁 |
| `sim_running` | 服务端推演中或事件流写入中 |
| `resolved` | 胜负、伤亡、`battle_id` 已写 |
| `cancelled` | 超时未应战、一方撤退等 |

| 字段（摘要） | 说明 |
|-------------|------|
| `room_id` | 主键 |
| `player_a_id` / `player_b_id` | 对阵双方 |
| `canonical_attacker_id` | 服务端推演视角下的「攻方」玩家 id（用于事件 `side: 'atk'|'def'`） |
| `duel_map_id` / `map_seed` | 专用地图 |
| `lineup_snapshot_json` | 开战瞬间 `main_lineup` 冻结 |
| `battle_seed` | 推演 RNG（`hashSeed(room_id, player_a, player_b, …)`） |
| `event_seq` | 已追加事件最大序号 |
| `status` | 上表 |
| `winner_player_id` | 结算后 |
| `battle_id` | 关联 `battles` |

**门闸**：复用 `validateMainLineupBattleGateOnConn`；开战前 **禁止** 改编组（快照后改卡不生效）。

### 12.4 视角镜像（双方看到正确站位）

| 项 | 约定 |
|----|------|
| 服务端 | 存 **canonical** 格子坐标（`side: 'a'|'b'` 或 `atk`/`def`）；推演只在 canonical 空间运行 |
| 客户端 A | API `GET …/tactical-rooms/:id/view` 将 **己方** 映射为 `faction: 'player'`，对手为 `'enemy'`，部署在己方便利半场 |
| 客户端 B | 同一 `eventLog`，**视角变换** 后再喂给动画层（与道路 `spectator` 载荷思路一致，但双方均为真实对阵方） |
| 禁止 | 守方把攻方当 `npcGarrison` 随机槽位填充的 PVE 模式 |

### 12.5 权威推演（方案 A）

```
lineupSnapshots + duelMapPreset + battleSeed
        ↓
runPvpTacticalDuel(state, options)   // shared 或 backend/pvp/tactical/
        ↓
{ events[], finalState, battleLog[], rounds }
        ↓
写 battles（skipStatistics：不进 player_statistics）、pvp_tactical_room_events
（切磋＝模拟游玩：**不**写 player_cards 兵力伤亡、**不**进老兵 battle_count）
```

| 项 | 约定 |
|----|------|
| 内核职责 | 寻路、速度排序、自动 AI（`battleTurnAi`、阶段 3～5 AI）、阵型首回合、`calcDamage` 链 |
| 与自动对决 | **不** 在 `runPvpAutoDuel` 上叠格子；`pvp_auto_duel` 保留给第一阶段战略场景 |
| 公式单源 | 推演调用 **`combatSystem` 同构** 的 Node 实现（延续 `siegeCombatCore` 对齐策略）；禁止 PVP 独立伤害公式 |
| 输出 | **结构化事件**（见 §12.6），另可生成人类可读 `battleLog` 供战报 |

### 12.6 事件流（动画与第三阶段共用）

服务端 **`pvp_tactical_room_events`**（或 room JSON 内 append-only 数组）：

| 字段 | 说明 |
|------|------|
| `seq` | 单调递增 |
| `type` | 见下表 |
| `payload` | JSON（坐标、unitInstanceId、damage、crit、dodge、roundNum …） |

| `type`（MVP） | 客户端行为 |
|---------------|------------|
| `ROUND_START` | 回合标题 |
| `MOVE` | 单位移格 |
| `ATTACK` | 主动一击动画 |
| `COUNTER` | 反击 |
| `DAMAGE` | 飘字 / 兵力条 |
| `UNIT_ELIMINATED` | 移除棋子 |
| `FORMATION_APPLIED` | 首回合阵型（若有） |
| `BATTLE_END` | 跳转结算 |

**同步**：`GET /api/pvp/tactical-rooms/:roomId/events?afterSeq=N` 轮询（MVP）；可选 SSE/WebSocket。**双方在线**时各播放到相同 `seq`；**不要求** 帧级 lockstep。

**离线**：不订阅 events；房间进入 `sim_running` 后由服务端跑完推演；事后 **`GET …/tactical-rooms/:id/result`** + 战报 + 可选 **全量 replay**（`afterSeq=0`）。

### 12.7 在线判定与遇袭 UX（复用第一阶段）

| 项 | 约定 |
|----|------|
| 邀战 / 倒计时 | 复用 **AncientModal** + `pending` 轮询模式（披挂 ~10s、道路遇袭）；参数可配置 |
| 在线 | 「房间 `both_ready` 且 **N 秒内** 拉过 events 或 heartbeat」⇒ 推送实时动画；否则标记 `spectator_offline` 仍结算 |
| 未点确定 | 与自动对决一致：**照样推演**；结果进通信 / 战报 |
| 弹窗互斥 | 继续遵守 `worldMapOverlayRefs`、攻城优先、道路 `eventBusy` |

### 12.8 战报与 `battle_type`

| 项 | 约定 |
|----|------|
| 建议枚举 | **`pvp_tactical_duel`**（与 `pvp_field` / `pvp_defense` 及 `pvp_siege` 演示壳区分） |
| 存储 | `battles` + `rewards.eventReplay`（事件 JSON 或压缩引用） |
| 评分 | `battleScore.cjs`；倍率规则 **后续** 与自动对决对齐或单独立项 |

### 12.9 API 草案（MVP）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/pvp/tactical-rooms` | 创建邀战（`opponentPlayerId`, `duelMapId?`） |
| POST | `/api/pvp/tactical-rooms/:id/accept` | 应战 + 门闸 |
| GET | `/api/pvp/tactical-rooms/:id` | 房间元数据 + `view`（镜像后部署预览） |
| GET | `/api/pvp/tactical-rooms/:id/events` | `afterSeq` 增量事件 |
| POST | `/api/pvp/tactical-rooms/:id/start` | 双方 ready 后触发推演（或 accept 后自动） |
| GET | `/api/pvp/tactical-rooms/:id/result` | 结算、战报 id |
| GET | `/api/pvp/tactical-rooms/pending` | 待应战列表（合并原 pending 模式） |

错误码、幂等、锁键见 **12-road-encounter-api** 同级 **[`13-pvp-tactical-api.md`](../../00/00-base/02-architecture-split/13-pvp-tactical-api.md)**（✅ 步骤 6 已创建）。

### 12.10 代码组织与迁移（**强制**）

**原则**：与 PVE **不一致** 的代码 → **仅** 放在 PVP 类目下；**完全一致** 的才 `require` / `import` 共享模块。

| 层级 | 目录 | 内容 |
|------|------|------|
| 后端 | `backend/services/pvp/auto-duel/` | **`pvpAutoDuelSim.js`**、披挂裁定、战报日志；**从 `services/` 根迁出并重命名**（§12.14） |
| 后端 | `backend/services/pvp/tactical/` | **`runPvpTacticalDuel.js`**、`pvpTacticalRoomService.js`、事件持久化 |
| 后端 | `backend/routes/pvp/` | 聚合 `tactical-rooms` + 既有 `/api/pvp/*`（逐步迁入） |
| 前端 | `game/src/pvp/auto-duel/` | **`PvpAutoDuelReplay`**、自动对决观战载荷组装 |
| 前端 | `game/src/pvp/tactical/` | **`PvpTacticalBattleShell.jsx`**、**`pvpEventPlayer.js`**（消费 events，**不** 引用 `SmallMapBattle` 的 PVE 分支） |
| 前端 | `game/src/pvp/shared/` | `PvpDefenseOutcomeModal`、遇袭轮询 hook、`usePvpPending` |
| 共享 | `shared/data/pvp-duel/` · `pvpDuelMapGenerator.js` | 对决地图固化 JSON + 生成器（见 PVP_DUEL_MAP_RULES） |
| 共享 | `shared/battle/tacticalSim/`（或 `shared/pvp/tacticalSim/`） | 无 React 推演内核 + `.js` ESM 镜像 |

**禁止**：

- 在 `SmallMapBattle.jsx` 增加 `battleType === 'pvp_tactical_duel'` 分支跑 PVP 权威战；
- 在 `roadEncounterService` / `WorldMap` 内嵌战术推演循环（仅 **调用** `pvp/tactical` service）。

**第一阶段清理（第二阶段收尾时）**：

- 删除 `skipSiegeResult` 下 **与自动对决战果脱钩** 的本地自动开战演示（若战略场景已改播 `PvpAutoDuelReplay`）；
- 删除已无引用的自动对决观战 `BattleArena` 路径；
- **保留** 仍服务道路 / 披挂的自动对决裁定与回放，仅 **搬迁目录并重命名**（§12.14）。

### 12.11 为第三阶段预埋

| 项 | 约定 |
|----|------|
| 事件 `type` | 预留 **`PLAYER_ACTION`**（`move` / `attack` / `skill` / `endTurn`） |
| 房间 | `sim_running` 拆为 **`awaiting_actions`** ↔ **`resolving_step`**（第二阶段仅自动，不暴露） |
| 锁 | 同一 `roomId` 串行写入 events；第三阶段按回合合并双方指令再 `advance` |
| 客户端 | `PvpTacticalBattleShell` 预留手动操作面板挂载点；**不** 与 PVE `useManualBattle` 混文件 |

### 12.12 MVP 范围（第一期开发）

| 包含 | 不包含 |
|------|--------|
| 1v1、`main_lineup` 对打 | 战事约战 3v3（§11） |
| 一种 `duelMapId` 预制图 | 随机 `generateSmallMap` 对决 |
| 全自动战术推演 + 事件回放 | 手动操作（第三阶段） |
| 轮询 events；离线战报 | WebSocket（可二期优化） |
| 独立切磋入口 + API | 强制替换道路自动对决 |

### 12.13 实现落点（第二阶段目标树）

```
backend/services/pvp/
├── auto-duel/         # 一阶段：runPvpAutoDuel（§12.14 自 siegePvpSkirmish 迁入并改名）✅ 已迁；含 pvpGarrisonAutoDuelResolveService（17-5-3 改调 runPvpTacticalDuel）
├── tactical/          # 二阶段：房间/事件持久化，调用 shared 内核
│   ├── pvpTacticalRoomService.js   # ✅ 步骤 2：邀战/应战/取消状态机 + 快照 + 门闸 + 行锁 + battle_seed
│   ├── pvpTacticalSimRunner.js     # ✅ 步骤 5：触发内核推演 + 批量写 events + 战报（步骤 9：按方统计 + 评分入 rewards）+ 幂等/补偿。切磋＝模拟：saveBattle({skipStatistics}) 不进战绩、**不**写兵力伤亡/老兵
│   ├── pvpDuelReportStats.js       # ✅ 步骤 9：纯函数 按方 damageDealt/Taken/kills + calculateBattleScore（仅 rewards 展示，不计排行——产品决策 2026-06-03）
│   ├── pvpTacticalRoomService.test.cjs # ✅ 状态机单测（内存 DB、无推演）
│   └── pvpDuelReportStats.test.cjs # ✅ 步骤 9 单测（真实 finalState：跨方对称 + 评分自洽）
backend/routes/pvp/
└── tacticalRooms.js   # ✅ 步骤 6：/api/pvp/tactical-rooms（invite/accept/cancel/start/get/events/result/pending）+ 鉴权 + 参与者校验
backend/database/migrations/
├── create-pvp-tactical-rooms.sql        # ✅ 步骤 2（已登记 apply-pending-local-ddl；**本地已执行 2026-06-03**）
├── create-pvp-tactical-room-events.sql  # ✅ 步骤 2（已登记；rooms 须先于 events；**本地已执行**）
└── alter-battles-add-pvp-tactical-duel-type.sql # ✅ 步骤 6：battles.battle_type 增 pvp_tactical_duel（**本地已执行**，enum 已含 pvp_tactical_duel）
docs/00/00-base/02-architecture-split/13-pvp-tactical-api.md # ✅ 步骤 6：HTTP 契约（端点/错误码/幂等/afterSeq）
shared/data/pvp-duel/          # 固化 *.preset.json                                 ✅
shared/utils/pvpDuelMapGenerator.js                                                  # ✅
shared/utils/pvpDuelMapCatalog.js                                                    # ✅
shared/battle/tacticalSim/     # 推演内核（single shared kernel，权威）
├── runPvpTacticalDuel.js      # ✅ 已落地（步骤 4：真实 AI + 首回合阵型 + events/finalState/battleLog/确定性）
├── tacticalGridModel.js       # ✅ headless 走位/寻路（对齐 battleFlowManager.getMoveCost）
├── tacticalAi.js              # ✅ 走位/选敌（忠实移植 battleFlowManager.findBestMoveTarget 等）
├── formationModel.js          # ✅ 阵型（移植 formationSystem + applyFormationBuffs，泛化双侧朝向）
├── runPvpTacticalDuel.test.cjs # ✅ 确定性 + 事件不变量(含 FORMATION_APPLIED) + 5 真图冒烟
└── tacticalSimUnits.test.cjs   # ✅ tacticalAi / formationModel 纯函数单测
game/src/pvp/
├── auto-duel/
│   └── PvpAutoDuelReplay.jsx        # ✅ §12.14：原 components/game/SiegeReplayMini.jsx 迁入并改名（历史无 eventReplay 战报的文本兜底回放）
├── tactical/
│   ├── PvpTacticalBattleShell.jsx   # ✅ 步骤 7：拉房间/视角 + 还原对决图 + 轮询 events + 逐事件回放 + 结算横幅
│   └── pvpEventPlayer.js            # ✅ 步骤 7：消费 events[] 驱动 useBattleAnimations（只回放、不重掷）
└── shared/
game/src/components/comm/
└── BattleTab.jsx                    # ✅ 步骤 9：战报详情 rewards.eventReplay.roomId → 懒挂 PvpTacticalBattleShell「战术对决 · 回放」
game/src/services/
└── pvpTacticalApi.js                # ✅ 步骤 7：/api/pvp/tactical-rooms/* 客户端封装（JWT 自动附加）
shared/battle/tacticalSim/
├── pvpCanonicalView.js              # ✅ 步骤 7：canonical ↔ 观战者视角变换（纯函数，viewer='a' 纵向翻转）
├── pvpReplayState.js                # ✅ 步骤 7：buildInitialTroops + foldEvents（纯终态，与动画终态同语义）
└── pvpReplay.test.cjs               # ✅ 步骤 7：foldEvents 终态 ≡ 内核 finalState（viewer a/b/null）
```

> **客户端视角纯逻辑落点**：`pvpCanonicalView` / `pvpReplayState` 为无 React/DOM 的纯函数，置于 `shared/battle/tacticalSim/`（`type: module`，可 Node 单测，与内核 `finalState` 直接对账）；`game/src/pvp/tactical/` 仅保留依赖 `useBattleAnimations`/DOM 的 `pvpEventPlayer` 与 React 壳 `PvpTacticalBattleShell`。回放**只**消费服务端 `DAMAGE.casualties/remain`，暴击/闪避表现取 `ATTACK/COUNTER.result`，**绝不**在客户端重掷。

> **内核落点说明**：推演内核采用 ESM `.js`（`shared` 为 `type: module`，与生成器/目录同构）；后端 `pvp/tactical` 服务以 `await import()` 调用，事件持久化与房间状态机在步骤 2/5 实装。

### 12.14 命名统一（**二阶段步骤 1 执行**）

原 **skirmish / 模拟演练 / siegePvp*** 与全项目 **`pvp_*` / `pve_*` 对决命名**不一致。二阶段迁入 `pvp/` 时 **一并重命名**（可先 re-export 旧名 1 个版本，**禁止** 长期双名并存）。

#### 12.14.1 管线对照（产品层）

| 阶段 | 管线 ID（文档 / 日志） | 中文 | 与 `battles.battle_type` |
|------|------------------------|------|---------------------------|
| 一 | **`pvp_auto_duel`** | 自动对决 | **不变**：道路 `pvp_field`、守方 `pvp_defense`；披挂链路与客户端演示仍可出现 `pvp_siege` |
| 二 | **`pvp_tactical_duel`** | 战术对决 | 新枚举 **`pvp_tactical_duel`** |
| 三 | （沿用二） | 战术对决 · 手动 | 同上，事件含 `PLAYER_ACTION` |

**说明**：`battle_type` 表示 **战报产品分类**；`pvp_auto_duel` 表示 **推演实现**。道路战报仍写 `pvp_field`，底层调用 **`runPvpAutoDuel`**。

#### 12.14.2 符号与文件映射表

| 现名（迁移前） | 新名（定稿） |
|----------------|-------------|
| `runSiegePvpSkirmish` | **`runPvpAutoDuel`** |
| `siegePvpSkirmish.js` | **`pvp/auto-duel/pvpAutoDuelSim.js`** |
| `siegePvpResolveService.js` | **`pvp/auto-duel/pvpGarrisonAutoDuelResolveService.js`** |
| `doResolveAuthoritativeSiegePvp` | **`doResolveAuthoritativeGarrisonAutoDuel`** |
| `resolveAuthoritativeSiegePvp`（路由导出） | **`resolveAuthoritativeGarrisonAutoDuel`** |
| `buildDefenderSiegePvpBattleLog` | **`buildDefenderPvpAutoDuelBattleLog`** |
| `siegeDefenseBattleLog.js` | **`pvpAutoDuelBattleLog.js`** |
| `formatSkirmishLineForDefender` | **`formatAutoDuelLineForDefender`** |
| `rewards.skirmishBattleLog` | **`rewards.autoDuelBattleLog`**（读档 **兼容旧键 1 版本** 可选，默认敏捷开发 **不兼容**） |
| `SiegeReplayMini.jsx` | **`PvpAutoDuelReplay.jsx`** |
| `applySkirmishWarMoraleDelta` | **`applyPvpAutoDuelMoraleDelta`** |
| `applySkirmishDeltaForWar` | **`applyPvpAutoDuelDeltaForWar`** |
| `applyAuthoritativeSiegePvpAttackerLineupCasualties` | **`applyAuthoritativePvpAutoDuelAttackerLineupCasualties`** |
| 目录 `pvp/skirmish/` | **`pvp/auto-duel/`** |
| `runTacticalAutoBattle`（§12 草案） | **`runPvpTacticalDuel`** |

**保持不改（语义属战略/攻城，非推演管线名）**：

- HTTP：`POST /api/pvp/siege-resolve`、`encounter-authoritative-resolve`（路径稳定；实现委托 `pvp/auto-duel`）。
- 客户端 `battleType: 'pvp_siege'`：仅 **演示壳** 类型，与 `pvp_auto_duel` 推演正交。
- `siegeCombatCore.cjs`：全战斗伤害单源，**非** PVP 专属。

#### 12.14.3 实施要求

| 项 | 约定 |
|----|------|
| 执行时机 | [17-5-2](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md) **步骤 1**（迁目录 + 本表重命名，同一 PR） |
| 搜索清理 | 合并后仓库内 **无** `skirmish` / `SiegePvpSkirmish` 标识符（注释、文档除外：可在 CHANGELOG 记一笔「原 skirmish」） |
| 测试 | 道路裁定、披挂 `siege-resolve`、`warMorale` 自动对决增量、战报回放各 1 条冒烟 |
| AI 征发军团 | `aiConscriptLegionService` 调用改为 **`runPvpAutoDuel`**（仍不写 `battles` 行） |

---

**最后复盘**：2026-06-03（v2.4.0：回归校验同步——第二阶段 §12（17-5-2）+ 真实两链迁移（17-5-3）均已实装；状态/§1.1/§3/§10/§12 标题/§12.13 树由「待开发」更新为「已实装」；§3 增 17-5-3 迁移横幅（披挂/道路实调 `runPvpTacticalDuel`、口径沿用 §3～§5）；后端命名统一已完成（前端 `SiegeReplayMini`/`skirmishBattleLog` 收尾见 §12.14）。）  
**复盘**：2026-05-29（v2.3.0：§12.2 对决地图合意；链 PVP_DUEL_MAP_RULES；§12.14 重命名。）
