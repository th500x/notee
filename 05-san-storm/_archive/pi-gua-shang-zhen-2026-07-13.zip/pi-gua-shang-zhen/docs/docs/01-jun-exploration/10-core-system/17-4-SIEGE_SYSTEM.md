# 攻城系统（流程与战事）

**文档版本**：v2.0.4  
**最后复盘**：2026-06-09（§2.4 攻城次数：initiate API 服务端扣次 + 失败回滚；前端不再 POST consume）
**状态**：已实装（PVE 中立抢城 + PVP 势力攻城双线）

---

## 0. 关联文档与系统索引

| 主题 | 文档 | 关系 |
|------|------|------|
| 势力战事 · 大本营 · 24h | [17-3-WAR_SYSTEM.md](./17-3-WAR_SYSTEM.md) | PVP 前置；守方打 **大本营** 见该文 §8 |
| **城防细则**（卡池、披挂、驻地、NPC 配置） | [13-2-CITY_DEFENSE_SYSTEM.md](./13-2-CITY_DEFENSE_SYSTEM.md) | **权威**；本文不重复 |
| 战术战斗 · 门闸 | [17-1-COMBAT_SYSTEM.md](./17-1-COMBAT_SYSTEM.md) | ≥200 兵 + 粮草 |
| 战事阶段门禁 | [11-3-FACTION_POLICY_SYSTEM.md](./11-3-FACTION_POLICY_SYSTEM.md) §5 | 仅 PVP + 有临时政策行时 |
| 攻城次数 | [15-2-SERVER_REFRESH_AND_LIMITS.md](./15-2-SERVER_REFRESH_AND_LIMITS.md) §3.2 | 与探索共用 +6/18 网格 |
| 城战奖赏拆分 | [11-3](./11-3-FACTION_POLICY_SYSTEM.md) §3.2、[17-3](./17-3-WAR_SYSTEM.md) §10.2 | `siegeRewardSplitPolicy` |
| **披挂/道路权威对决** | [17-5-DUEL_SYSTEM.md](./17-5-DUEL_SYSTEM.md) | skirmish、`siege-resolve`、道路 `encounter-authoritative-resolve` |
| 战报 | [18-1-BATTLE_REPORT_SYSTEM.md](./18-1-BATTLE_REPORT_SYSTEM.md) | 披挂 skirmish vs 棋盘战 |
| 库表 | [50-tables-battle.md](../../00/00-base/01-database-split/50-tables-battle.md) | `wars`、`battles` |

---

## 1. 功能概述

本文描述 **「对目标城发起一次攻城战斗」** 的全链路：选目标 → 占战线锁 → 小型图战斗 → 写战果 → 可能易主。

**城防配置**（守城卡池 A/B、披挂、驻地编组、NPC 编制）一律见 **[13-2](./13-2-CITY_DEFENSE_SYSTEM.md)**。

### 1.1 PVE 与 PVP 对照（必读）

| 维度 | **PVE · 中立抢城** | **PVP · 势力攻城** |
|------|-------------------|-------------------|
| 目标城 | **无** `faction_id`（中立） | **已占** 且存在 **active `wars_pvp`** |
| 战事表 | **`wars`** | **`wars_pvp`**（不写 `wars`） |
| 多势力 | 多攻方 **抢桶**（`faction_kills`） | **攻守两方**；易主归 **攻方势力** |
| 并发 | 攻方势力 **最多 1 场** active PVE 攻城 | 同城 **最多 1 场** active PVP |
| 发起 API | `POST /api/cities/:cityId/siege` | `POST /api/pvp-wars/:id/city-siege` |
| 战果 API | `POST /api/cities/siege-result` | `POST /api/pvp-wars/:id/city-siege-result` |
| 战报关联 | `battles.war_id` | `battles.pvp_war_id` |
| 防守队列 | **仅 NPC**（中立无玩家守军） | **披挂 → 驻地 → NPC** |
| 易主 | NPC **全灭** → **`faction_kills` 最高** 者占城 | NPC **全灭** → **攻方势力** 占城（见 17-3） |
| 阶段门禁 | 无 | 有临时政策时走 `warPhaseService` |

**硬边界**：`cityService.initiateSiege` / `recordSiegeResult` **拒绝** 已占城与玩家守军类型；`pvpWarService` **拒绝** 写 `faction_kills` 抢桶逻辑。

---

## 2. 共用门槛与战线锁

### 2.1 开战门闸

| 项 | 数值 / 规则 |
|----|-------------|
| 上阵总兵力 | ≥ **200**（`MIN_MAIN_LINEUP_TROOPS_BATTLE`） |
| 出征粮草 | 每支已装备部队 `ceil(当前兵力/20)` 之和 |
| 攻城次数 | 消耗 1 次（与探索共用配额，见 15-2）；**扣次在服务端 initiate 内完成**（见 §2.4） |
| 大地图 phase | 须 **IDLE / RETURNING**（`WorldMap.startSiegeForCity`） |

### 2.2 有效守军（PVP · 玩家档）

| 项 | 规则 |
|----|------|
| 驻地/披挂出场 | 整编后 **当前总兵力 ≥ 800**（`MIN_GARRISON_TOTAL_TROOPS`） |
| 队列顺序 | ① 披挂（`on_duty` + 同势力同城）→ ② 驻地（`player_garrison`，去掉已披挂者）→ ③ NPC |
| 同玩家 | 队列中 **只出现一次**（披挂优先） |
| 披挂槽位 | `garrison_slot = 0`（锁键用，非 DB 驻地槽） |

详述：[13-2](./13-2-CITY_DEFENSE_SYSTEM.md)。

### 2.3 战线锁

| 项 | 规则 |
|----|------|
| TTL | **60 秒**（`SIEGE_LOCK_TTL_MS`）；成功 `siege-result` 释放，超时自动失效 |
| 玩家档锁键（PVP） | `def\|{pvpWarId}\|{playerId}\|{garrison_slot}` |
| NPC 批锁键（PVE） | `def\|{warId}\|_npc\|{批次号}` |
| NPC 批锁键（PVP） | 同上结构，war 段为 `pvpWarId` |
| NPC 分批 | 存活支数按序 **每 4 支一批**；批次被占则试下一批 |
| 并行上限 | 批次数（非全城仅 1 人） |

### 2.4 攻城次数扣减（服务端权威）

| 项 | 规则 |
|----|------|
| 存储 | `player_events.siege_quota_*`（**玩家全局桶**，与 URL 中 `cityId` 无关） |
| 算法 | 与探索共用 `hourlyQuotaWithRestWindow`（15-2 §3.2） |
| **扣次时机** | **`cityService.consumeSiegeQuotaForBattleStart`**：各 **initiate** API 内向客户端返回开战数据**之前**扣 1 次 |
| PVE 中立城 | `POST /api/cities/:cityId/siege` → `cityService.initiateSiege` |
| PVP 攻目标城 | `POST /api/pvp-wars/:id/city-siege` → `pvpWarService.initiateAttackerCitySiege` |
| 守方攻大本营 | `POST /api/pvp-wars/:id/base-camp-siege` → `pvpWarService.initiateBaseCampSiege` |
| 失败回滚 | 抢锁失败、粮草门闸失败、御驾附军失败等 → **`refundSiegeQuotaOnce`** |
| 前端 | `GET …/siege-quota` 只读展示与按钮置灰；**禁止**开战后再 `POST …/siege-quota` `consume` |
| 结算「继续」 | 与首次开战相同：再调对应 initiate → 服务端再扣 1 次（匪寨继续不扣，见 17-7） |

---

## 3. PVE 路径（中立城）

### 3.1 发起

| 步骤 | 说明 |
|------|------|
| 校验 | 非己方；**必须中立**（已占则报错，引导走 PVP） |
| 城型 | 中立 PVE 仅 **大/中/小城**（不含关隘、据点等） |
| 距离 | 首次开新城时 `assertNeutralPveTargetInMapRange` |
| 次数 | **`consumeSiegeQuotaForBattleStart`**（§2.4） |
| NPC | 无编制或全灭则 `generateNpcGarrison` |
| `wars` 行 | 同城已有 active 则复用；否则新建 `war_{cityId}_{ts}` |
| 大本营 | 首次参战前 **`pveWarBaseCampService.ensurePveAttackerBaseCamp`**（复用 PVP 选位/NPC）；写入 `wars.attacker_base_camps[factionId]` |
| 存量补建 | **`backfillAllActivePveBaseCamps`**：后端启动约 3s、PVE tick（5min）、`GET …/active-pve-base-camps` 前；攻方势力来源：`faction_kills` 键、已写 `attacker_base_camps` 键、`battles` 任意参战、`faction_bulletins`（48h 内 PVE 开战公告，仅在前述皆空时）；缺列 **`wars.attacker_base_camps`** 时 API 503 + 日志 FATAL |
| 并发 | 本势力 active PVE 攻城 **≥1 场** 且非本城参与者 → **拒绝** |
| 返回 | `warId`、本批最多 **4** 支 NPC、`defenderType: 'npc'`、`npcBatchIndex` |

### 3.2 战果 `recordSiegeResult`

| 步骤 | 说明 |
|------|------|
| 前置 | 客户端 **`POST /api/battles`** 落战报（可重试） |
| 上报 | `POST /api/cities/siege-result` · `killedIndices`、`result`、`silverSpent` |
| 击杀统计 | 仅计 **alive→dead** 的支数，写入 `faction_kills[factionId]` |
| `npc_killed` | 与 JSON **阵亡支数** 同步（权威，防历史累加误差） |
| 易主 | **`npc_garrison` 存活 = 0** → `wars.completed`，**击杀最多势力** 得城 |
| 易主后 | 清 `on_duty`、剥驻地、`stripGarrisonOnCityConquest`、**`applyCityOwnershipHandoff`**（势力 + NPC + 长官：**中城/大城→君主**） |
| 奖励 | 见 §5；城战政策拆分入 **`faction_reserve` pool** |

**禁止**：`defenderType !== 'npc'` 进入本路径。

### 3.3 PVE 与势力宣战

势力 **`openPveWarOnNeutralCity`**（公告/AI）可预建 `wars` 行并扣 **发动消耗**（见 17-3 §3）；玩家仍用 `initiateSiege` 加入同一 `wars` 抢桶。

### 3.4 24h 到点自动结案（与 PVP tick 对齐）

| 项 | 说明 |
|----|------|
| 时限 | 新建 `wars` 行写入 `start_time=NOW()`、`end_time=NOW()+24h`（与 **17-3 §5** PVP 单场墙钟一致） |
| tick | `cityService.tickActivePveWars`：`server.js` 每 5 分钟 + `listActivePveSiegeTargetsForMap` 拉列表前 |
| 结果 | `status=completed`、`winner_faction_id=NULL`（中立守军仍存）；释放 NPC 批锁；参与势力公告 |
| 攻防 | 到期后 `initiateSiege` / `recordSiegeResult` 拒绝并提示自动结案 |

---

## 4. PVP 路径（已占城 + active 战事）

### 4.1 前置

| 项 | 规则 |
|----|------|
| 战事 | 目标城须有 **`wars_pvp.status = active`** |
| 身份 | 调用者为 **攻方势力** 成员 |
| 阶段 | 若存在 **`wars_pvp_policies`** 行 → `warPhaseService.assertPlayerSiegeAllowed` |
| 御驾友军 | 临时政策启用且打 **驻地/NPC** 档时，`imperialMarchService` 可附友军单位 |

### 4.2 发起 `initiateAttackerCitySiege`

**次数**：入口内 **`consumeSiegeQuotaForBattleStart`**（§2.4）；失败路径 **`refundSiegeQuotaOnce`**。

按 §2.2 队列扫描，首个可锁定的防守者：

| `defenderType` | 行为 |
|----------------|------|
| `pvp_online` | 披挂；返回阵容 → **`challenge`** → 等待窗 → **`siege-resolve`**（详 **17-5** §4） |
| `player_garrison` | 驻地；异步 PVE（守方卡池作 NPC 形态） |
| `npc` | 玩家档均跳过后的 NPC 批次（同 §2.3） |

返回载荷含 `pvpWarId`、防守者信息、本战 NPC 切片等；前端组装 `BattleArena` / `SmallMapBattle`。

### 4.3 战果 `recordAttackerCitySiegeResult`

| 步骤 | 说明 |
|------|------|
| 写回 | `POST /api/pvp-wars/:id/city-siege-result` |
| 范围 | 三类防守者通用；更新 `side_stats`、城市 `npc_garrison`、披挂解除等 |
| 占城 | 城内 NPC **全灭** → **`applyPvpTargetCityOwnershipHandoff`**（内含 `applyCityOwnershipHandoff`：攻方得城、罢免长官、清 NPC；另清本营、迁离守方等，见 [17-3 §7.3](./17-3-WAR_SYSTEM.md)） |
| 奖励 | 与 PVE 同口径击杀银两 + 贡献/装备；**城战政策拆分** 入攻方 **`faction_reserve` pool** |
| 披挂 | 走 `siegePvpResolveService` → 本函数（**不写** `wars`） |

### 4.4 守方打攻方大本营

**不属于「攻城内防线」**，属战事另一目标：

| 项 | 说明 |
|----|------|
| API | `POST …/base-camp-siege`、`…/base-camp-siege-result` |
| 次数 | 同 §2.4（`initiateBaseCampSiege` 内扣次 + 失败回滚） |
| 顺序 | 披挂 → **大本营 NPC**（无驻地） |
| 出征粮草 | 常规出征消耗 × **2**（UI 在「攻打大本营」按钮下提示） |
| 胜负 | 大本营 NPC 归零 → 攻方战事 **failed**（见 17-3） |

---

## 5. 单场战斗奖励（NPC 线 · 权威数值）

按 **本场实际击杀** 的 NPC 支稀有度累计（`shared/utils/siegeKillEconomyByRarity.cjs`）：

| 稀有度 | 银两/支 | 贡献/支（胜且有击杀） |
|--------|---------|------------------------|
| common | 10 | 1 |
| rare | 20 | 2 |
| epic | 30 | 3 |
| legendary | 40 | 4 |
| core | 50 | 5 |

另：**5%** 装备掉落（按本场最高敌方稀有度）；净银两经 **城战奖赏政策** 拆分（默认个人 100%）。

---

## 6. 客户端结算顺序

| 顺序 | 动作 |
|------|------|
| 1 | 小型图战斗结束 |
| 2 | **`POST /api/battles`**（`battle_type`：`pve_siege` / `pvp_siege` 等） |
| 3 | **`siege-result` 或 `city-siege-result`** |
| 4 | 释放战线锁、刷新 tooltip / 浮层 |

若 **`battleScore > 0`** 且战报未落库（`battleReportSaved === false`），服务端在攻城结算内 **补加** `player_statistics.total_battle_score`（日志 `[siege-score-fallback]`）。

**大地图分流**（`WorldMap.startSiegeForCity`）：`cityRow.faction_id` 为空 → PVE `/cities/.../siege`；否则查 active PVP → `warAPI.initiateAttackerCitySiege`。

---

## 7. 披挂 PVP 等待窗（摘要）

| 项 | 规则 |
|----|------|
| 等待 | **`WAIT_IN_GAME` / `WAIT_NOT_IN_GAME` = 10 秒**（`pvpService`） |
| 超时 | 服务端 **`POST /api/pvp/siege-resolve`** 权威裁定 |
| UI | 攻方倒计时 → 裁定 → 简化回放 → 再写 PVP 战果 |
| 详述 | [13-2](./13-2-CITY_DEFENSE_SYSTEM.md) 披挂遇袭、[18-1](./18-1-BATTLE_REPORT_SYSTEM.md) |

---

## 8. 实现落点

| 职责 | PVE | PVP |
|------|-----|-----|
| 发起 | `cityService.initiateSiege` | `pvpWarService.initiateAttackerCitySiege` |
| 战果 | `cityService.recordSiegeResult` | `pvpWarService.recordAttackerCitySiegeResult` |
| 大本营 | — | `pvpWarService.recordBaseCampSiegeResult` |
| 有效守军 / 队列 | `garrisonService.buildDefenderLineupForCityDefense` 等 | 同上 |
| 披挂裁定 | — | `siegePvpResolveService.js` |
| 阶段门禁 | — | `warPhaseService.js` |
| 路由 | `routes/cities.js` | `routes/pvpWars.js`、`routes/pvp.js` |
| 前端 | `WorldMap.jsx` | `warApi.js` + `WorldMap.jsx` |
| loot / 贡献 | `smallMapBattleLootService.js` | 同上 |

---

## 9. 待实装 / 不在本文

| 项 | 说明 |
|----|------|
| 出征前统一取消披挂 | 部分入口待与 UI 同批补齐（17-3 §14） |
| 快速战斗 / 旧异步伪代码 | 已废止；以现行 `BattleArena` 为准 |
| 驻军所建筑数值 | 产品备忘，无独立运行时 |

---

**最后复盘**：2026-05-27（v2.0.0：PVE/PVP 双线对照表；击杀奖励稀有度表；移除 ASCII/代码块/更新日志；城防细节归 13-2。）
