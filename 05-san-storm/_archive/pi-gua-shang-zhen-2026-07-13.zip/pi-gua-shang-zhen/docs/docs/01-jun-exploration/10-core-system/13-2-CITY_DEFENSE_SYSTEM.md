# 城防与城市守备

**文档版本**：v2.0.4  
**最后复盘**：2026-05-27  
**状态**：已实装（驻地编组、披挂、NPC 守军、攻城防守队列；主城设置已实装）

---

## 0. 关联文档与系统索引

| 主题 | 文档 | 关系 |
|------|------|------|
| 城市类型、人口、城防数值 `defense` | [13-1-CITY_SYSTEM.md](./13-1-CITY_SYSTEM.md) §一·七 | `siegeCityDefenseMult` 权威 |
| 攻城流程、PVE/PVP、配额、易主 | [17-4-SIEGE_SYSTEM.md](./17-4-SIEGE_SYSTEM.md) | 发起/结算 API；本文为 **城防配置权威** |
| 势力战事、大本营 | [17-3-WAR_SYSTEM.md](./17-3-WAR_SYSTEM.md) | PVP 攻城前置 |
| 战斗门闸、伤害 | [17-1-COMBAT_SYSTEM.md](./17-1-COMBAT_SYSTEM.md) | ≥200 兵、城防倍率入防守方 |
| 战报、积分、披挂回放 | [18-1-BATTLE_REPORT_SYSTEM.md](./18-1-BATTLE_REPORT_SYSTEM.md) | skirmish 标签、`×1.5`/`×2` |
| 新手指引设主城 | [10-1-TUTORIAL_SYSTEM.md](./10-1-TUTORIAL_SYSTEM.md) | 创角后 `main_city_id` 为 NULL |
| 编组 UI · 占用 · 槽位 | [22-2-TROOP_LINEUP_SYSTEM.md](../../00/20-data-layer/22-2-TROOP_LINEUP_SYSTEM.md) | 驻地 A/B、14 字段、五城上限 |
| 底栏/浮层入口 | [32-1-BOTTOM_TABS.md](../30-frontend/32-1-BOTTOM_TABS.md) §3.1 · §4 | `LineupTab` · `GarrisonLineup` |
| NPC 稀有度档 | [22-1-TROOP_SYSTEM.md](../../00/20-data-layer/22-1-TROOP_SYSTEM.md) §九 | 与匪寨 tier 对齐 |
| 库表 | [00-base/01-database-split/00-overview.md](../../00/00-base/01-database-split/00-overview.md) §3.2 | `player_garrison`、`players.on_duty*` |

---

## 1. 功能概述

本文是 **已占领城池** 上「守城」的 **主文档**：**驻地编组**（`player_garrison`）、**披挂上阵**（`players.on_duty`）、**NPC 守军**（`cities.npc_garrison`），以及攻城时的 **防守队列、战线锁、各档结算路径**。

**攻城发起、战事、配额、易主** 见 [17-4](./17-4-SIEGE_SYSTEM.md)；**不在此重复** 全流程，仅写城防侧规则。

### 1.1 术语

| 术语 | 含义 |
|------|------|
| **主城** | 玩家选定、存放备用部队/兵营关联的 **一座** 己方大城或中城（`players.main_city_id`） |
| **驻地编组** | 某城 **守城卡池 A/B**（`player_garrison`，与主城 **解耦**） |
| **披挂上阵** | 以 **上阵编组** 待战本城（`on_duty` + `on_duty_city_id`） |
| **有效守军** | 经整编后 **当前总兵力 ≥ 800** 的防守者（**不得** 仅凭 `is_active`） |

### 1.2 与攻城 PVE / PVP 的关系

| 目标城 | 玩家守军 | NPC |
|--------|----------|-----|
| **中立**（无 `faction_id`） | **不参与**（仅 NPC） | PVE `wars` 分批 |
| **已占** + active `wars_pvp` | **披挂 → 驻地 → NPC** | PVP 同序 |

---

## 2. 守城双通道（驻地 vs 披挂）

| 维度 | 驻地编组（卡池 A/B） | 披挂上阵 |
|------|---------------------|----------|
| 目的 | 额外部队 **异步** 守城 | 主公 **上阵编组** 待战；遇袭可 **观战** |
| 主数据 | `player_garrison`（每城 `garrison_slot` 1/2） | `players.on_duty`、`on_duty_city_id` |
| 兵力来源 | 槽内 **未上阵** 部队卡 | **`is_equipped`** 上阵部队 |
| 卡牌实例 | 驻地槽用 **未上阵** 卡（`is_equipped = FALSE`） | 披挂战力来自 **上阵编组**（`is_equipped`） |
| 玩家状态 | **可** 同时：本城（或其它城）有 `player_garrison` 行 **且** `on_duty` 待战本城 | 同左；`saveGarrison` **不** 因披挂而禁止保存驻地 |
| 攻城虚拟槽 | `garrison_slot` = **1、2…** | **`0`**（锁键用，无 `player_garrison` 行） |
| 战斗形态 | 客户端 `BattleArena` + 战果 API | **`POST /api/pvp/siege-resolve`** 权威裁定 |
| `defenderType` | `player_garrison` | `pvp_online` |

**单次攻城命中（队列，非配置互斥）**：同一 `player_id` 在攻方一次 `initiateAttackerCitySiege` 中 **只出一个防守档**。实现：`getCityOnDutyDefenders` 优先；`getCityGarrisonDefenders` SQL 已排除 `on_duty = TRUE` 的玩家行；`pvpWarService` 再 `filter` 掉已在披挂列表中的 `player_id`（`garrisonOnly`）。故该玩家 **以披挂档出战**（`defense_source = main_lineup`，`garrison_slot = 0`），**不会** 再以驻地 A/B 槽身份二次入队——**驻地行仍保留在库**，披挂解除后照常参与队列。

---

## 3. 产品常量（与后端单一来源）

| 常量 | 值 | 用途 |
|------|-----|------|
| `MIN_GARRISON_TOTAL_TROOPS` | **800** | 驻地/披挂 **出场**、列表、遇袭、攻城筛选 |
| `MIN_MAIN_LINEUP_TROOPS_BATTLE` | **200** | 攻方（及通用）**开战** 上阵总兵力 |
| `MAX_GARRISON_CONFIGURED_CITIES` | **5** | 玩家全图最多 **5 座城** 有驻地卡写入 |
| `SIEGE_LOCK_TTL_MS` | **60s** | 战线锁（见 17-4） |
| 主城更换费用 | **500** 银两 | 非首次 |
| 主城更换冷却 | **24h** | `main_city_changed_at` |
| 披挂遇袭等待 | **10s** | 守方在局/不在局同值（`pvpService`） |

**`is_active`（`player_garrison`）**：保存时按 **当时** 配置是否 ≥800 写入；战后可能仍为 TRUE 但当前兵力已不足——**对外统计与攻城一律再跑** `buildDefenderLineupForCityDefense`。

---

## 4. 驻地编组（`player_garrison`）

**编组界面、槽位、五城上限、14 字段占用、可选卡池** → [22-2-TROOP_LINEUP_SYSTEM.md](../../00/20-data-layer/22-2-TROOP_LINEUP_SYSTEM.md) §3～§4。下文仅保留 **守备/战后** 语义。

### 4.1 战后

| 项 | 规则 |
|----|------|
| `is_active` | 结算后四路合计 **<800** → 置 **FALSE** |
| 兵力写回 | 客户端 `defenderLineupTroopUpdates` 经 **PVP 战果** 或 **PVE siege-result** 写 `player_cards`（半血存活） |
| 易主 | 胜方占城 → `stripGarrisonOnCityConquest` 删除 **非胜方** 驻地行 |

---

## 5. 披挂上阵

### 5.1 开关规则

| 项 | 规则 |
|----|------|
| API | `POST /api/garrisons/:playerId/on-duty`，body：`onDuty`、`cityId` |
| 开启条件 | 目标城 **已占** 且 **与玩家同势力** |
| 关闭 | `onDuty: false`，清空 `on_duty_city_id` |
| 出场门槛 | 上阵编组 **当前总兵力 ≥ 800**（与驻地同常量） |

### 5.2 遇袭流程（产品）

| 步骤 | 说明 |
|------|------|
| 1 | 攻城方命中披挂档后，守方收到 **遇袭通知** |
| 2 | **约 10 秒** 倒数；**[确定]** = **观战**（非「接受对战」） |
| 3 | 未点确定：**照样结算**；可事后看战报 |
| 4 | 攻守均由 **AI 代打**；胜负以 **`siege-resolve`** 为准 |
| 5 | 锁键须用 **`garrison_slot = 0`**；**禁止** 默认成 `1` 误拉驻地数据 |

**战斗推演、API、SiegeReplayMini、与道路遭遇对照** → **[17-5-DUEL_SYSTEM.md](./17-5-DUEL_SYSTEM.md)** §4。

### 5.3 与驻地结算差异

| 档 | 演算 | 战报 |
|----|------|------|
| 披挂 | 服务端 skirmish + `siege-resolve` | 攻守 **各一条**；守方 `buildDefenderSiegePvpBattleLog`（`[攻方]`/`[守军]` 行） |
| 驻地 | 客户端单场 + **单次** 战果 API | 守方 recordOnly：**同源日志 + 驻守页眉** |

简化回放与道路遭遇 **同一组件链** → **17-5** §6；守方优先 `rewards.skirmishBattleLog`，无则不出 `SiegeReplayMini`。

---

## 6. NPC 守军

### 6.1 生成与支数

| 城态 | 支数来源 |
|------|----------|
| **已占领**（`faction_id` 非空且 `status = owned`） | `NPC_TROOP_COUNT_OWNED` 按 `city_type`（见下表） |
| **中立** | **无** 默认代码表；须管理端生成、`troopCountOverride` 或沿用既有 JSON 槽位数 |
| 势力池 | `generateNpcGarrison` 按城 season/势力筛 `config_troops` / `config_characters` |
| 稀有度 | 与匪寨 tier 四槽循环（`city_type` → normal/rare/epic） |

**已占领默认支数**（`cityService.NPC_TROOP_COUNT_OWNED`）：

| `city_type` | 支数 |
|-------------|------|
| city_small | 200 |
| city_medium | 280 |
| city_major | 360 |
| gate | 360 |
| fort | 280 |

存库：`npc_garrison` JSON `{ units[], ledgerAt }`；`npc_garrison_alive` = 存活支数。

### 6.2 已占城日更（M1）

| 项 | 规则 |
|----|------|
| 触发 | `initiateSiege` 内：已占、存活 **< 编制上限**、过 **ledgerAt 次日 8:00** |
| 恢复量 | `round(上限 × 0.5)` 支，复活 dead 槽至 `min(上限, 当前存活+恢复量)` |
| 不重掷 | **不** 整表 `generateNpcGarrison`；中立/攻破全灭重掷 **不受** 本条 |
| 实现 | `applyOwnedCityNpcPartialDailyRecovery` |

### 6.3 攻城分批

| 项 | 规则 |
|----|------|
| 每批 | 最多 **4** 支存活 NPC |
| 锁 | `def|{warId或pvpWarId}|_npc|{批次}` |
| 并行 | 批次数条线（非全城单锁） |
| `wars.npc_killed` | 与 JSON **阵亡支数** 同步；易主以 **存活=0** 为准（见 17-4） |

### 6.4 城防战斗倍率

- 来源：`cities.defense`（API **`cityDefense`**，策划约 **50～150**，基准 **100**）。
- 攻城（设计）：`siegeCityDefenseMult = cityDefense / 100`，仅作用于 **防守方有效防御**（`calcDamage` §5 `totalDef`）；野战/道路/大本营 **不传**。
- **实装**：系数入库 + UI + 战斗链（`shared/utils/siegeCityDefenseMult` · 开战 API 附带 `cityDefense`/`siegeCityDefenseMult` · 棋盘 `buildSiegeUnits` 标记 `_siegeCityDefender` · 服务端 `runSiegePvpSkirmish` 仅 normal 且 `def.faction==='enemy'` 传倍率）。
- 详 [13-1 §7](./13-1-CITY_SYSTEM.md)。

### 6.5 守方打攻方大本营（城防侧摘要）

| 项 | 规则 |
|----|------|
| NPC 支数 | 目标城满编 × **150%**（`BASE_CAMP_NPC_RATIO_TO_FULL_GARRISON`） |
| 出征粮草 | 常规出征 × **2**（`BASE_CAMP_SIEGE_FOOD_COST_MULTIPLIER`；大地图「攻打大本营」按钮下提示） |
| 城防倍率 | **不传**（同 §6.4 大本营） |
| 详述 | [17-3 §6·§8](./17-3-WAR_SYSTEM.md)、[17-4 §4.4](./17-4-SIEGE_SYSTEM.md) |

---

## 7. 攻城防守队列（实装）

> 一次 `initiateSiege` / `initiateAttackerCitySiege` **只命中一名** 防守者。下表为 **PVP 已占城**；**中立 PVE 仅走 NPC 分支**（见 17-4 §3）。

| 顺序 | 来源 | 过滤 |
|------|------|------|
| 1 | `getCityOnDutyDefenders` | 同势力、`on_duty_city_id` = 本城；**≥800**；`defense_source = main_lineup` |
| 2 | `getCityGarrisonDefenders` | 本城 `is_active` 且 **`on_duty` 为 FALSE/NULL**；**≥800** |
| 3 | 合并队列 | `[…onDuty, …garrisonOnly]`（同玩家 **不** 重复入队，见 §2） |
| 4 | 逐个尝试 | `buildDefenderLineupForCityDefense`；锁 `def|…|playerId|slot` |
| 5 | 全失败 | **NPC** 批次锁 |

**PVP 额外**：`warPhaseService` 阶段门禁（有 `wars_pvp_policies` 时）；御驾友军见 `imperialMarchService`（非披挂、有临时政策时）。

---

## 8. 攻城战报积分（排行榜）

相对 **仅 NPC** 场次，玩家守军难度更高，**攻守同倍率**（`getSiegeBattleScoreMultiplier` / 披挂 `battleScore.cjs`）：

| 对手档 | 倍率 |
|--------|------|
| NPC | ×1 |
| 驻地编组 `player_garrison` | ×1.5 |
| 披挂 `pvp_online` | ×2 |

---

## 9. 主城（存卡城市）

| 项 | 规则 |
|----|------|
| 数量 | 每玩家 **1** 座 |
| 可选类型 | **大城、中城**（己方已占） |
| 创角 | `main_city_id` **NULL**；引导内首次设置 |
| 更换 | `POST /api/players/:playerId/main-city`；首次免费；之后 **500 银 + 24h** |
| 长官 | 就任时可把 **NULL** 写成任职城；罢免后主城处理见 13-1 / 职位文 |
| 兵营 | `main_city_barracks_storage` 见 `mainCityBarracksStorageService`（与主城绑定，非跨城调兵） |

---

## 10. API 摘要

| 方法 | 路径 | 职责 |
|------|------|------|
| GET | `/api/garrisons/:playerId` | 全图驻地行 |
| GET | `/api/garrisons/:playerId/by-city/:cityId` | 单城 A/B |
| POST | `/api/garrisons/:playerId/:slot?cityId=` | 保存槽位 |
| DELETE | `/api/garrisons/:playerId/:slot?cityId=` | 清空槽位 |
| POST | `/api/garrisons/:playerId/on-duty` | 披挂开关 |
| GET | `/api/garrisons/city/:cityId/defenders` | 防守者列表（已滤 ≥800） |
| GET | `/api/garrisons/city/:cityId/on-duty-count` | 本城披挂人数 |
| GET | `/api/garrisons/stats/cities` | 地图驻地统计 |
| POST | `/api/players/:playerId/main-city` | 设/换主城 |
| POST | `/api/cities/:cityId/siege` | PVE 发起（中立 NPC） |
| POST | `/api/pvp-wars/:id/city-siege` | PVP 攻城内防 |
| POST | `/api/pvp/siege-resolve` | 披挂权威裁定 |

---

## 11. 实现落点

| 职责 | 主要文件 |
|------|----------|
| 驻地 CRUD、有效守军过滤 | `backend/services/garrisonService.js` |
| 防守单位构建 | `backend/services/garrisonBuildService.js` |
| NPC 生成/日更 | `backend/services/cityService.js` |
| PVP 队列发起/战果 | `backend/services/pvpWarService.js` |
| 披挂裁定 | `backend/services/siegePvpResolveService.js`、`siegePvpSkirmish.js`、`pvpService.js` |
| 主城 | `backend/services/playerMainCityService.js` |
| 路由 | `backend/routes/garrisons.js` |
| 大地图入口 | `game/src/components/game/WorldMap.jsx`、`WorldMapCityInfoBlock` |
| 驻地 UI | `GarrisonLineup.jsx`、`garrisonApi.js` |
| 击杀经济 | `shared/utils/siegeKillEconomyByRarity.cjs` |

---

## 12. 延后 / 未实装

| 项 | 说明 |
|----|------|
| 随身携带 **20 张**上限 | 设计目标；**当前未强制**校验 |
| 守城 **官职序** 自动排序 | 产品设想；队列 **未** 按官职重排 |
| 同城规模 **最大守城玩家数**（10/20/30/50） | 产品表；**未** 硬限制 `initiateSiege` |
| 卡池 A/B **全员各打一轮** | 长期设想；现网 **单档命中** |

---

**最后复盘**：2026-05-27（v2.0.4：§5 战斗细节链 **17-5**；披挂/道路 skirmish 不再在本文展开。）
