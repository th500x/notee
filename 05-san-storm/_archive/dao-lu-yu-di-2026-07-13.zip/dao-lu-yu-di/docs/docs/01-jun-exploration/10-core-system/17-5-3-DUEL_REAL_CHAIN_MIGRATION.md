# 真实链条战术化 · 披挂 + 道路 迁移到 `runPvpTacticalDuel`

**文档版本**：v1.9.0  
**最后复盘**：2026-06-03  
**状态**：**已实施完成**（阶段 0–6 全部落地并经实测；披挂 `siege-resolve` 真实经济 E2E 待 staging）。已把第一阶段两条真实链条（**攻城披挂** `pvp_siege`/`pvp_defense`、**道路遭遇** `pvp_field`）的底层推演由 **自动对决 `runPvpAutoDuel`** 替换为 **战术对决 `runPvpTacticalDuel`**（17-5 §12）。规格以 17-5 §3～§6、§12 为准；本文补 **决策、阶段、落点、风险、回滚**。

> 与「阵前切磋」彻底区分：切磋＝**模拟游玩**（`skipStatistics`、不写伤亡/老兵/计分，见 17-5-2 步骤 9）；本文两条链＝**全真实结算**（伤亡 / 老兵 `battle_count` / 士气 / 战绩 / 排行 **全部保留**）。两者共用同一推演内核，**写回路径相反**。

---

## 0. 关联文档

| 主题 | 文档 |
|------|------|
| 对决总览 · 自动对决 · 战术对决 | [17-5-DUEL_SYSTEM.md](./17-5-DUEL_SYSTEM.md) §3～§6、§12 |
| 二阶段实施（内核 / 房间 / 事件 / 壳） | [17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md](./17-5-2-TACTICAL_AUTO_DUEL_IMPLEMENTATION.md) |
| skirmish → 自动对决命名映射 | 17-5 **§12.14.2** |
| 战报枚举 / 服务端直写 | [18-1-BATTLE_REPORT_SYSTEM.md](./18-1-BATTLE_REPORT_SYSTEM.md) §2.1 §8 |
| 攻城 / 城防披挂 | [17-4-SIEGE_SYSTEM.md](./17-4-SIEGE_SYSTEM.md) · [13-2-CITY_DEFENSE_SYSTEM.md](./13-2-CITY_DEFENSE_SYSTEM.md) |
| 道路遭遇 API | [12-road-encounter-api.md](../../00/00-base/02-architecture-split/12-road-encounter-api.md) |
| 上阵编组（单位来源） | [22-2-TROOP_LINEUP_SYSTEM.md](../../00/20-data-layer/22-2-TROOP_LINEUP_SYSTEM.md) |

---

## 1. 锁定决策（2026-06-03）

| 决策 | 选定 | 含义 |
|------|------|------|
| **D1 对决地图来源** | **对决图池随机选 1 张** | 复用 `pvpTacticalRoomService.pickDuelMapId()`；披挂/道路本无地图，随机选池内图 |
| **D2 城防 / 地形加成** | **先给内核接 `cityDefense`/地形，保数值口径** | 自动对决披挂给守方 `cityDefense`；战术内核现 `calcDamageSeeded(...,null)` 不计，直接替换会让守方变弱，故先补 |
| **D3 回放承载** | **一步到位** | 复用 `pvp_tactical_rooms`/`pvp_tactical_room_events` 承载事件；客户端多入口切 `PvpTacticalBattleShell` 事件流回放 |
| **D4 灰度** | **直接替换，不留双轨** | 两服务直接改调 `runPvpTacticalDuel`；保留 `sim_failed` 补偿（非回退轨） |

---

## 2. 现状对照（两链同构）

| 要素 | 披挂① `siegePvpResolveService.doResolveAuthoritativeSiegePvp` | 道路② `roadEncounterService`（权威裁定） |
|------|---------------------------------------------------------------|-------------------------------------------|
| 单位来源 | `buildDefenseUnitsFromMainLineup` → `mapBuiltUnitsToSiegeNpcFormat` | 同左 |
| seed | `hashSeed([pvpWarId, challengeId, attackerId, defenderId])` | `hashSeed([encounterId, attackerId, defenderId])` |
| 推演 | `runSiegePvpSkirmish(atk, def, seed, { cityDefense })` | `runSiegePvpSkirmish(atk, def, seed)` |
| sim 输出 | `attackerWon / killedIndices / battleLog[] / rounds / attackerTroopsEnd[] / defenderTroopsEnd[] / battleSeed` | 同左 |
| 守方写回 | `pvpWarService.recordAttackerCitySiegeResult`（`defenderLineupTroopUpdates` + 士气） | `recordEncounterBattleSettlement`（同形 + 士气） |
| 攻方伤亡 | `garrisonService.applyAuthoritativeSiegePvpAttackerLineupCasualties`（**含 `battle_count`+1 → 老兵**） | 同左 |
| 战报 | `pvp_siege`（攻）+ `pvp_defense`（守 `recordOnly`） | `pvp_field`（攻）+ `pvp_defense`（守 `recordOnly`） |
| 排行 | `total_battle_score += score` | `battleService.applyBattleScore` |
| 客户端回放 | `PvpAutoDuelReplay`（文本 battleLog） | 同左 |

**关键洞察**：两链「推演 → 写回」之间只隔一层 `sim.*` 数据形状。替换核 = **换推演 + 适配 `finalState` → 同形 `sim.*`**，写回零改动。

---

## 3. 内核输入输出与映射

`runPvpTacticalDuel({ duelMapId, lineupSnapshots:{a,b}, battleSeed, sideLabels, /* 阶段1 新增 */ defenseBonus })`
→ `{ events[], finalState, battleLog[], winnerSide, rounds }`

- 攻方 = **side a**（canonical 攻方/邀战方）；守方 = **side b**。
- `finalState.units[].instanceId = ${side}_${index}`，**index 对齐快照顺序** ⇒ 可还原与自动对决同序的 `attackerTroopsEnd/defenderTroopsEnd`。
- `winnerSide === 'a'` ⇒ `attackerWon = true`。
- `killedIndices` = side b 中 `currentTroops === 0` 的 index 集合。

---

## 4. 阶段实施

### 阶段 0 · 命名统一（17-5 §12.14 步骤 1）✅ 已完成 2026-06-03
- **后端（本轮做）**：
  - `siegePvpSkirmish.js → services/pvp/auto-duel/pvpAutoDuelSim.js`，`runSiegePvpSkirmish → runPvpAutoDuel`。
  - `utils/siegeDefenseBattleLog.js → services/pvp/auto-duel/pvpAutoDuelBattleLog.js`，`buildDefenderSiegePvpBattleLog → buildDefenderPvpAutoDuelBattleLog`、`formatSkirmishLineForDefender → formatAutoDuelLineForDefender`。
  - `siegePvpResolveService.js → services/pvp/auto-duel/pvpGarrisonAutoDuelResolveService.js`，`resolveAuthoritativeSiegePvp → resolveAuthoritativeGarrisonAutoDuel`、`doResolveAuthoritativeSiegePvp → doResolveAuthoritativeGarrisonAutoDuel`。
  - `garrisonBuildService.applyAuthoritativeSiegePvpAttackerLineupCasualties → applyAuthoritativePvpAutoDuelAttackerLineupCasualties`（`garrisonService` 再导出同步）。
  - `warMoraleCore.applySkirmishWarMoraleDelta → applyPvpAutoDuelMoraleDelta`、常量 `WAR_MORALE_SKIRMISH_DELTA → WAR_MORALE_AUTO_DUEL_DELTA`；`warMoraleService.applySkirmishDeltaForWar → applyPvpAutoDuelDeltaForWar`。
  - 调用点同步：`routes/pvp.js`、`roadEncounterService`、`aiConscriptLegionService`、`pvpWarService`、`pvp/tactical/pvpTacticalRoomService`（`hashSeed` 改取 `../auto-duel/pvpAutoDuelSim`）、`warMoraleCore.test.cjs`。
- **决策更新**：采用**干净重命名（无长期 re-export 双名）**，符合 17-5「禁止长期双名并存」；后端为自洽闭环（前端走 HTTP 路径，路由路径不变），故无需 shim。
- **前端命名收尾（✅ 已于回归校验完成 2026-06-03）**：`SiegeReplayMini.jsx → PvpAutoDuelReplay.jsx`（含内部 `parseSiegeReplayTimeline → parsePvpAutoDuelReplayTimeline`，5 处 import + JSX 全切）与 `rewards.skirmishBattleLog → autoDuelBattleLog`（两处后端写：`roadEncounterService`/`pvpGarrisonAutoDuelResolveService`；一处前端读：`BattleTab`；**敏捷不双读旧键**——历史守方战报的文本兜底回放退役，事件流为主）。至此**前后端均无 `skirmish`/`SiegeReplayMini` 代码标识符**（仅余「原 …」溯源注释）。
- **验证**：后端全量 `node --check` 绿；`warMoraleCore.test.cjs` 4/4 绿；require 全图解析（含 `routes/pvp` → resolve service → 全依赖）通过；`runPvpAutoDuel` 同 seed 确定性 + 守城文案构建冒烟通过；后端侧 grep 仅剩「原 …」溯源注释与已执行迁移注释。

### 阶段 1 · 内核接城防 / 地形（D2）✅ 已完成 2026-06-03
- `runPvpTacticalDuel` 增入参 `defenseBonus: { a?, b? }`（值=cityDefense，如 100/150）：受击单元所在侧若有该值，按 `cityDefense` 注入 `calcDamageSeeded` options（`siegeCityDefenseMult = cityDefense/100`，复用 `resolveSiegeCityDefenseMultFromOpts`）。主动击取 `def.side`、反击取 `atk.side`（受击者侧）。
- 两处 `calcDamageSeeded` 第 3 参由 `null` 改传 `mapResult.terrain` → 地形防御（`getTerrainDefBonus`）+ 攻方地形适应（`*Adapt`）现已生效。
- 新增 helper `cityDefenseForSide(side)`；JSDoc + 头注记录；切磋默认不传 `defenseBonus` = 无城防（行为对既有切磋仅多了地形项，仍确定性）。
- **交付**：`runPvpTacticalDuel/pvpReplay/tacticalSimUnits/pvpDuelReportStats` 四测全绿（确定性断言同 seed 复现，非硬编码伤害值）；新增对照冒烟「带 `defenseBonus` 仍确定性 + 极高城防侧免伤获胜（减员不增）」。
- 已移除 `runPvpTacticalDuel.js` 的 `terrain=null` 独立项标注（17-5-2 §4 同步标记 ✅）。

### 阶段 2 · 结果适配器（纯函数 + 单测）✅ 已完成 2026-06-03
- 新增 `backend/services/pvp/tactical/tacticalToAutoDuelResult.js`：
  `({ winnerSide, finalState, attackerSnapshot, defenderSnapshot, attackerSide='a', defenderSide='b' }) → { attackerWon, winnerSide, attackerTroopsEnd, defenderTroopsEnd, killedIndices, defenderLineupTroopUpdates }`（与 `runPvpAutoDuel` 的 `sim.*` 同形）。
- 设计：以快照为基（取 `maxTroops/rarity/troopType/index/_troopInstanceId`），叠加 `finalState.units`（按 `${side}_${i}` instanceId 对位）的 `currentTroops/initialTroops`；攻方标 `faction='player'`、守方 `'enemy'`，满足 `calculateBattleScore` 读 `faction/rarity/initialTroops/currentTroops`；攻方写回仅需 `currentTroops`。`killedIndices` 用守方 `npc.index`（缺省退化数组下标），口径同 `runPvpAutoDuel`。
- 输入校验、平局（winnerSide null ⇒ attackerWon=false）、缺 finalUnit 安全退化（用快照开战兵力）。
- **交付**：`tacticalToAutoDuelResult.test.cjs` 全绿——纯映射（跨方对位/faction/killedIndices 仅守方/index↔snapshot/lineup 更新）+ 喂 `buildTroopsFor*Score`+`calculateBattleScore` 得有限分 + **真实内核 round-trip 兵力守恒（Σcurrent==troopsRemain）**。

### 阶段 3 · 事件承载 + 房间（D3）✅ 已完成 2026-06-03
- 新增 `pvpTacticalSimRunner.persistResolvedDuelRoom({ attackerId, defenderId, duelMapId, battleSeed, lineupSnapshots, sim, battleIdA?, battleIdB?, season? })`：
  **一步**建 `status='resolved'` 房间行（`player_a_id=攻`、`player_b_id=守`、`canonical_attacker_id=攻`，写 `lineup_snapshot_json`/`battle_seed`/`duel_map_id`/`winner_*`/`battle_id_a/b`/`event_seq=maxSeq`，`accepted_at/sim_started_at/resolved_at=NOW()`）+ 批量写 `pvp_tactical_room_events`（seq 连续，**含 seq0 BATTLE_START**），**room+events 同事务原子**；返回 `{ roomId, maxSeq }`。
- 复用既有事件写法（与切磋 `resolveSim` 同 INSERT 模式，DRY），与切磋流（invited→both_ready→sim_running→resolved）区分：本函数**不**做门闸/扣粮/快照冻结（调用方已自带）；仅供回放、**非**权威战果，调用方 best-effort 包裹（落库失败不阻断真实结算）。
- `rewards.eventReplay = { source:'pvp_tactical_room_events', roomId, maxSeq }` 由阶段 4 调用方补（本阶段 helper 已返回 roomId/maxSeq）。
- 鉴权：**无需改路由**——`tacticalRooms.js` 的 `authorizeParticipant` 已允许 `playerAId`/`playerBId`（+admin），攻/守均可经 `GET /api/pvp/tactical-rooms/:id` 拉取回放。
- **交付**：DB 冒烟通过——建 resolved 房 + 全量事件落库（COUNT==内核事件数）、读回 `getRoom`/`getRoomEvents` 校验状态/winner/快照/seq 对齐、afterSeq 独占语义、清理（cascade）。
- **🐞 顺带修复（阻断级，原属阶段 5）**：`PvpTacticalBattleShell` 轮询起始 `lastSeq=0` + `getEvents` 独占 `seq>afterSeq` ⇒ **永远取不到 seq0 BATTLE_START**，`renderInitial` 拿不到放兵坐标 → 回放永不起播。改 `lastSeq=-1`（首拉 `afterSeq=-1` 取全量含 BATTLE_START）。此 bug 同时阻断步骤 9 已交付的切磋回放入口。

### 阶段 4 · 两服务替换推演（D4 直接换）✅ 已完成 2026-06-03
- **选图**：`roomService.pickDuelMapIdForSeed(seed)`（同 seed→同图，整场对决「仅凭 battleSeed+双方快照」即可复现；房间另存 `duel_map_id` 兜底）。
- `pvpGarrisonAutoDuelResolveService`：`runPvpAutoDuel → runPvpTacticalDuel`（`defenseBonus.b = city.defense`，`sideLabels {a:'攻方',b:'守军'}`），经 `tacticalToAutoDuelResult` 得 `sim.*`（`battleLog/rounds/battleSeed` 由 `sim` 包装层补齐），**写回/士气/老兵/战报/排行全部不动**。
- `roadEncounterService`：同上（无 cityDefense，`sideLabels {a:'攻方',b:'守方'}`）。
- **房间/事件**：两服务在裁定内 `await simRunner.persistResolvedDuelRoom(...)`（best-effort，try/catch 解耦），战报 id 先行生成回填 `battle_id_a/b`，`rewards.eventReplay = { source, roomId, maxSeq }` 写入攻/守双方战报 + 实时 outcome/`authoritative_resolution_json`，供阶段 5 客户端切壳。
- **关键决策**：
  - 老兵 `battle_count`+1 经 `applyAuthoritative…AttackerLineupCasualties` 保留（真实战，**非**切磋；`saveBattle` 不传 `skipStatistics`，排行/统计正常累计）。
  - kernel `battleLog` 与旧自动对决格式不同（无「第 N 次攻击」前缀），`buildDefenderPvpAutoDuelBattleLog` 回合头仍匹配、伤害行原样透传（不崩、可读）；事件流回放为主视图，文本退居其次。
- **失败补偿**：推演/落库异常 → 不写半截，日志告警（沿用各自 try/catch）；落房间失败仅丢回放入口，权威结算照常。
- **验证**：`node --check` ×3 + require 图（无循环、导出齐全）+ 真实编组 DB 冒烟（选图确定性→内核 133 事件→适配器→落房间→读回 seq 连续含 BATTLE_START→清理）+ 适配器/内核/士气单测全绿。

### 阶段 5 · 客户端多入口切壳（D3）✅ 已完成 2026-06-03
- **回放壳泛化**：`PvpTacticalBattleShell` 新增 `title` prop（默认 `阵前切磋`），头部/`mapLabel` 复用 → 真实链条传 `城防对决`/`道路遭遇`。
- **战报 `BattleTab`**：去掉 `battleType==='pvp_tactical_duel'` 限制，改为**凡 `rewards.eventReplay.roomId` 存在即挂壳**（切磋 + `pvp_siege/pvp_defense/pvp_field` 统一入口）；title 按 `battleType`/`roadEncounterId` 推导。
- **攻方披挂 + 道路攻方**：`usePvpSiegeAdjudication` / `useWorldMapStrategicBattles` 在 `authoritativeReplayOverlay` payload 加 `eventReplayRoomId`(+title)；`WorldMapAlertOverlays` 分支——有房间 → 懒加载 `PvpTacticalBattleShell`（`onClose=onPlaybackComplete` 进结算），否则退回旧 `SiegeReplayMini` portal。**必须切**：内核 battleLog 无「第 N 次攻击」前缀，旧 `SiegeReplayMini` 解析不动会卡死。
- **守方披挂 + 道路守方**：`PvpDefenseOutcomeModal` 加 `outcome.eventReplay.roomId` 守卫的「战术对决 · 回放」按钮（懒加载壳）；道路守方复用此 modal（新战 battleLog 不过 `次攻击` 启发式 → 跳过旧全屏 `SiegeReplayMini` 直达此 modal，自动覆盖）。
- **旧战报零回归**：无 `eventReplay` → `roomId=null` → 不显示新按钮；`canSiegeReplay`/`canReplay`（要求 `次攻击`+`[攻方]`）对内核新日志为 false，故新战报只显示事件流入口、不再显示旧简化回放。
- **交付**：四入口均能播事件流（`PvpTacticalBattleShell` 独立懒加载 chunk）；旧 `SiegeReplayMini` 仅保留给历史无 `eventReplay` 的战报。`vite build` 432 模块全绿。

### 阶段 6 · 回归冒烟 ✅ 已完成 2026-06-03
- **确定性单测全绿**：`runPvpTacticalDuel`(5 图)、`pvpReplay`(viewer a/b/null 折叠对齐内核)、`tacticalSimUnits`、`tacticalToAutoDuelResult`、`pvpDuelReportStats`、`warMoraleCore`、`pvpDuelMapGenerator`。
- **两配置非破坏性管线冒烟**（真实编组镜像；仅建/清自身房间，**不碰** `player_cards`/统计/经济）：披挂(守方城防 +150) / 道路(无城防) 各一场，断言①选图确定性②内核双跑事件数/胜方/回合一致③适配器 `sim.*` 长度对齐 + `killedIndices` 界内 + 兵力守恒(end∈[0,start]) + `attackerWon` 与内核一致④落房间/事件读回(`status=resolved`、`battle_id_a/b` 回填、`duel_map_id`、`event_seq=maxSeq`、seq 连续含 BATTLE_START)⑤`rewards.eventReplay` 形状。
  - **城防有效性佐证**：同镜像编组下「披挂(城防150)→守方胜、攻方全灭」vs「道路(无城防)→攻方胜」，证 `defenseBonus.b` 实际影响裁定。
- **静态校验**：两服务 `node --check` + require 图(无循环) + `vite build` 432 模块全绿（阶段 4/5）。
- **✅ 道路真实经济写回 E2E 已实跑通过（自镜像 `1IQF` + 全量快照/还原）**：把改动收敛到可完美还原集合——`road_encounters` `season=''`/无 `gatekeeper` 跳过撤退与守门关闭；**预选「攻方落败」`encounterId`**（确定性）使 `result≠win` 跳过装备/声望/白银掉落路径 ⇒ 实改表仅 `player_cards`/`players`/`player_statistics`（全行快照回写）+ `battles`/房间/事件/`road_encounters`（删自建行）。断言全过：resolve `attackerWon=false`、双方战报含 `rewards.eventReplay.roomId`、房间 `resolved`+173 事件含 `BATTLE_START`、二次调用幂等且事件不重复、用库存 `battle_seed+duel_map_id+快照` 重跑内核复现胜方/事件数、lineup `battle_count` 4/4 增加、`player_statistics` 真实累计（lose+win，+1038/+1308 分，证非 `skipStatistics`）。**还原经独立校验 bit 级干净**：跑前/跑后 `total_battle_score=37626`、`total_battles=34`、`Σbattle_count=131`、`Σcurrent_troops=9200` 完全一致；零孤儿行。
- **披挂 `siege-resolve` 真实经济 E2E 待 staging**：与道路同源新代码（`runPvpTacticalDuel`+适配器+`persistResolvedDuelRoom`），但 stage 需 active `wars_pvp`+城池+披挂守军槽，留待测试库；道路 E2E 已覆盖「适配器→写回→双方战报+eventReplay→房间/事件→幂等→确定性」全链。

---

## 5. 风险与一致性

| 风险 | 处置 |
|------|------|
| **城防口径变化**（D2 核心） | 阶段 1 内核接 `cityDefense`；对照冒烟守口径 |
| **老兵 `battle_count` 必须保留**（与切磋相反） | 复用 `applyAuthoritativeSiegePvpAttackerLineupCasualties`（含 `battle_count`+1），**不**走 `skipStatistics` 路径 |
| 确定性 | seed 沿用各自 `hashSeed` 输入；内核 bit-identical |
| 兵力门槛 / 阵型 | 门槛 ≥200 不变；阵型加成内核已含 |
| 事件体积 | 3v3 ~150 事件/场，落 `_events` 表（非塞 rewards），与切磋同 |
| 无双轨回退（D4） | 保留 `runPvpAutoDuel` 函数（AI 征发等仍用）；如需紧急回退，单点改回服务内调用即可 |
| 文本回放退场 | 历史战报无 `eventReplay` 仍走旧 `SiegeReplayMini`；新战报一律事件流 |

## 6. 回滚
直接替换无 flag：回退 = 在两 resolve 服务内把 `runPvpTacticalDuel`+适配器单点改回 `runPvpAutoDuel`（保留旧调用为注释/旧分支一版）。客户端 `BattleTab` 泛化挂壳对旧战报无副作用（无 `eventReplay` 即不挂）。

---

**最后复盘**：2026-06-03（v1.9.0：**回归校验收口**——①前端命名收尾完成（阶段 0 遗留）：`components/game/SiegeReplayMini.jsx → pvp/auto-duel/PvpAutoDuelReplay.jsx`（内部 `parseSiegeReplayTimeline → parsePvpAutoDuelReplayTimeline`，5 处 import 改 `@/pvp/auto-duel/…`）+ `rewards.skirmishBattleLog → autoDuelBattleLog`（后端 2 写/前端 1 读，不双读旧键），全库已无 `skirmish`/`SiegeReplayMini` 代码标识符；②修 `pvpTacticalSimRunner` 切磋战报 `scoreGrade → battleGrade`（战报列表/纪念图统一读 `battleGrade`，原显示评级为 `-`）；③补 `validationSchemas/battles.js` 缺失的 `pvp_tactical_duel` 枚举；④同步架构文档（`50-battle-system` 披挂/道路改记 `runPvpTacticalDuel`、`10-backend-layout` 旧文件名更新、`03-1`/`50-tables-battle` 旧名清理）与 17-5/17-5-2 状态。`vite build` 432 模块绿、后端 `node --check` 绿、`pvpDuelReportStats`/`tacticalToAutoDuelResult` 单测绿。）  
**复盘**：2026-06-03（v1.8.0：**道路真实经济写回 E2E 已实跑通过**——自镜像 `1IQF`+预选攻方落败+全量快照/finally 还原，把改动收敛到 `player_cards`/`players`/`player_statistics`（全行回写）+自建行删除；断言全过（双方战报含 `eventReplay.roomId`、房间 resolved 173 事件、幂等、库存 seed/map/快照重跑复现、`battle_count` 4/4 增、`player_statistics` 真实累计），**还原经独立校验 bit 级干净**（跑前后聚合完全一致、零孤儿）。披挂 `siege-resolve` 真实 E2E 待 staging（同源新代码，stage 需 active war+城池+披挂槽）。至此 17-5-3 阶段 0–6 全部落地并经实测。）  
**复盘**：2026-06-03（v1.7.0：**阶段 6 回归冒烟（非破坏性）已完成**——确定性单测全绿（内核/回放折叠/sim-units/适配器/报表统计/士气/选图）；两配置非破坏性管线冒烟（披挂城防150 / 道路无城防）断言选图与内核确定性、适配器 `sim.*` 不变量（长度/击杀界内/兵力守恒/`attackerWon` 对齐）、房间/事件读回、`rewards.eventReplay` 形状，且**仅清自身房间不碰玩家经济**；城防有效性获佐证（同编组城防→守方胜、无城防→攻方胜）。**完整真实经济写回 E2E 暂缓至 staging**（本地单玩家、跨多表改经济，回滚风险高于收益），已在文档列出 staging 断言清单。至此 17-5-3 阶段 0–6 全部落地，真实披挂①/道路②链条已切到 `runPvpTacticalDuel`+事件流回放。）  
**复盘**：2026-06-03（v1.6.0：**阶段 5 客户端多入口切壳已完成**——`PvpTacticalBattleShell` 加 `title` prop 复用于切磋/城防/道路；`BattleTab` 泛化为「凡 `rewards.eventReplay.roomId` 即挂壳」（扩到 `pvp_siege/defense/field`）；攻方披挂(`usePvpSiegeAdjudication`)+道路攻方(`useWorldMapStrategicBattles`)在 `authoritativeReplayOverlay` 加 `eventReplayRoomId`，`WorldMapAlertOverlays` 分支懒加载壳（关闭即进结算）——**此切换是必须的**，因内核 battleLog 无「第 N 次攻击」前缀、旧 `SiegeReplayMini` 解析不动会卡死；守方披挂+道路守方经 `PvpDefenseOutcomeModal` 加事件回放按钮统一覆盖。旧战报无 `eventReplay` → 不挂新壳、`canSiegeReplay` 对新内核日志为 false，零回归。`vite build` 432 模块全绿、`PvpTacticalBattleShell` 独立 9.7kB 懒 chunk。下一步阶段 6：回归冒烟（披挂 `siege-resolve`、道路裁定、`warMorale` 增量、双方战报回放、确定性各 1 条）。）  
**复盘**：2026-06-03（v1.5.0：**阶段 4 两服务替换推演已完成**——披挂①/道路② 裁定核心由 `runPvpAutoDuel` 换成 `runPvpTacticalDuel`+`tacticalToAutoDuelResult` 适配器，包装成 `sim.*` 同形对象，**下游写回/士气/老兵 `battle_count`/双方战报/排行积分全部沿用旧代码零改动**；新增 `roomService.pickDuelMapIdForSeed(seed)` 确定性选图；两服务在裁定内 best-effort `persistResolvedDuelRoom` 落 resolved 房+全量事件，战报 id 先行生成回填，`rewards.eventReplay` 写入攻/守战报+实时 outcome 供阶段 5 切壳。城防经 `defenseBonus.b` 入内核；切磋 vs 真实战的区别仅在 `skipStatistics`——真实战不传，统计照常累计。验证：`node --check`+require 图+真实编组 DB 冒烟（内核133事件→落房间→读回 seq 连续）+适配器/内核/士气单测全绿。下一步阶段 5：客户端四入口 `PvpAutoDuelReplay`/`SiegeReplayMini` → `PvpTacticalBattleShell(roomId)` 切壳 + `BattleTab` 泛化挂壳。）  
**复盘**：2026-06-03（v1.4.0：**阶段 3 事件承载+房间已完成**——新增 `persistResolvedDuelRoom` 一步建 resolved 房+全量事件（同事务），返回 `{roomId,maxSeq}` 供 `rewards.eventReplay`；路由鉴权已天然支持双方；DB 冒烟通过。**顺带修复阻断级 bug**：`PvpTacticalBattleShell` 轮询 `lastSeq=0` 漏取 seq0 BATTLE_START → 改 `-1`（同时修好步骤 9 切磋回放）。下一步阶段 4：两服务替换推演（披挂传 `defenseBonus.b=city.defense` + 接适配器 + 落房间/eventReplay）。）
**复盘**：2026-06-03（v1.3.0：**阶段 2 结果适配器已完成**——纯函数 `tacticalToAutoDuelResult` 把内核 `finalState` 映射成 `runPvpAutoDuel` 同形 `sim.*`，下游伤亡写回/计分/录战无需改；单测 + 真实内核 round-trip 兵力守恒全绿。下一步阶段 3：事件承载 + 房间（resolve 链内建 `pvp_tactical_rooms`/写 events + `rewards.eventReplay`）。）
**复盘**：2026-06-03（v1.2.0：**阶段 1 内核接城防/地形已完成**——`runPvpTacticalDuel` 增 `defenseBonus.{a,b}=cityDefense`（注入 `calcDamageSeeded` options，受击侧增防）+ 两处第 3 参改传 `mapResult.terrain`（地形防御/适应生效）；四测全绿 + 城防对照冒烟通过；17-5-2 §4 独立项已勾除。下一步阶段 2：结果适配器 `tacticalToAutoDuelResult.js`。）
**复盘**：2026-06-03（v1.1.0：**阶段 0 命名统一后端已完成**——`skirmish/SiegePvp` 系标识符全量改为 `PvpAutoDuel/AutoDuel/GarrisonAutoDuel`，三文件迁入 `services/pvp/auto-duel/`，采干净重命名无 shim；前端 `SiegeReplayMini` 与 `skirmishBattleLog` 数据键并入阶段 5。验证：node --check 全绿、warMoraleCore 4/4、require 全图解析、runPvpAutoDuel 确定性冒烟通过。下一步阶段 1：内核接 `cityDefense`/地形。）
**复盘**：2026-06-03（v1.0.0：锁定 D1 随机图 / D2 内核接城防 / D3 事件流一步到位 / D4 直接替换；定阶段 0～6 与落点、风险、回滚。）
