# 战略大地图 · 道路行军

**文档版本**：v2.2.8  
**最后复盘**：2026-06-09（入城/入寨 `targetPoiId` 时不因末段道路格友方叠站拒止行军）  
**状态**：**已实装**（沿路移动、守门、占格、遭遇触发、粮草与 POI 入城）

> 原编号 **31-6-STRATEGIC_ROAD_PVP** 已更名为本文，以突出 **道路与行军**；**战斗推演、遇袭 UI、战报** 见 **[17-5-DUEL_SYSTEM](../10-core-system/17-5-DUEL_SYSTEM.md)**。

---

## 0. 关联文档与系统索引

| 主题 | 文档 | 关系 |
|------|------|------|
| 道路栅格与 merged 图 | [31-2-WORLD_MAP.md](./31-2-WORLD_MAP.md) | 道路层、坐标、生成管线 |
| 地图体系分界 | [31-1-MAP_SYSTEM.md](./31-1-MAP_SYSTEM.md) | 战略 vs 战术；浏览/行军模式 **〇.1** |
| **道路遭遇 · 战斗** | [17-5-DUEL_SYSTEM.md](../10-core-system/17-5-DUEL_SYSTEM.md) | skirmish、裁定、回放（**非本文**） |
| 道路 HTTP 契约 | [12-road-encounter-api.md](../../00/00-base/02-architecture-split/12-road-encounter-api.md) | 路径、幂等、错误码 |
| 库表 `road_encounters` | [60-tables-other.md](../../00/00-base/01-database-split/60-tables-other.md) §3.2.24 | 遭遇实例与 `players.road_*` |
| M2 敌对判定 | [13-1-CITY_SYSTEM.md](../10-core-system/13-1-CITY_SYSTEM.md) §1.6.2（7） | 不同 `faction_id` 即互敌 |
| 匪寨最后一格豁免 | [17-7-BANDIT_SYSTEM.md](../10-core-system/17-7-BANDIT_SYSTEM.md) §1.2.1 | `san_*_bandit_*` 末步不登记遭遇 |
| 势力池垫粮 | [11-1-FACTION_SYSTEM.md](../10-core-system/11-1-FACTION_SYSTEM.md) | `faction_reserve` pool 支取上限 |

---

## 1. 功能概述

玩家在 **战略大地图** 上沿 **道路格网** 移动：可设 **守门（来战）**、与敌对玩家 **同格触发遭遇**、消耗 **粮草**（含势力池兜底），并可把终点设为 **道路格** 或 **己方城心 / 本郡匪寨**。

| 属于本文 | 不属于本文 |
|----------|------------|
| `road/move` 路径权威、扣粮、逐格动画 | 战斗推演、SiegeReplayMini、战报写入细则 → **17-5** |
| `road_intercept` 守门开关与战败关闭 | 攻城队列、披挂配置 → **17-4**、**13-2** |
| 占格、叠站、遭遇登记、交战格锁 | 道路 CSV/merged 生成 → **31-2** |
| `road-presence`、pawn 立点与在线过滤 | 完整外交系统（M2 临时规则见 §5） |

**规模假设**：单郡同屏约 **百人级**；同步宜分郡 / 节流，非全服广播。

---

## 2. 坐标与移动前提

| 项 | 约定 |
|----|------|
| 可走段 | 单次 `road/move` 的 **道路步** 须在 **可通行道路集合** 内（**31-2**、服务端 `loadRoadGrid`） |
| 玩家坐标 | DB：`players.road_jun_id` + `road_position_x/y`；**`GET /profile`** 出口 **camelCase**（`roadJunId` / `roadPositionX` / `roadPositionY`）；与 `road_encounters.position_*`、大地图 `gx/gy` **同一套** |
| 双读 helper | 共享 **`playerRoadStandFromProfile`**（`strategicMarchPoi.js`）对 API camelCase 与 DB snake_case **双读**，供离路出发 footprint、前端路径预览与服务端 BFS **同源** |
| 权威路径 | 有 `targetPoiId` 或纯道路终点时，服务端用 **`strategicMarchPoi` BFS 重算 `resolvedPath`**；**扣粮步数** 只认服务端路径 |
| 纯道路终点 | 无 `targetPoiId` 时以请求 `path` **末格** 为意图，**不**采信客户端中间格 |
| 道路与野怪 | **不在** 道路格刷 NPC，避免与占格判定冲突 |

---

## 3. 守门（开战模式 · `road_intercept`）

| 项 | 约定 |
|----|------|
| 开启 | 银两 **50**（**0→1** 扣一次；已为 1 不重复扣）→ `players.road_intercept = 1` |
| 时长 | **无** 自动超时 |
| 关闭 | 守门方在 **本模式触发的遭遇战中战败** → 置 **0**；战胜则保持直至战败 |
| 展示 | `road_intercept=1` 时本人与他人 pawn **头像赤红脉冲**（`.ws-map-self-pawn__avatar--intercept`）；他人 **无** 来战操作条 |

语义：表达「道路上拦截敌对行军」；与 **§5** 遭遇登记配合（`gatekeeper_player_id`）。

---

## 4. 占格与 `moveAlongRoad` 语义

### 4.1 非敌对 — 允许叠站

| 项 | 约定 |
|----|------|
| 判定 | M2：同 `faction_id`；任一方 `faction_id` 为空 → **非敌对** |
| 途经 / 落点 | 可 **同坐标叠站**，**不** 登记遭遇，路径 **继续** |
| 主动落点 | 行军确认前，若 **终点格** 上 `road-presence` 已有 **友方在线** → 客户端 **禁止** 发起 `road/move`（争空降被动叠站仍由服务端允许） |
| 入城/入寨 | 带 **`targetPoiId`** 时落点为 **POI 几何中心**（§7），**不** 对寻路末段 **道路格** 做上述友方叠格拒止（该格上友方仅属「途经/邻接」，非最终落脚点） |

### 4.2 敌对 — 遭遇 + 路径截断

踏入下一格前，**先** 校验移动方 **开战门闸**（上阵 ≥200、出征粮草；与攻城披挂同 **`validateMainLineupBattleGateOnConn`**，裁定细节 **17-5**）：

| 分支 | 结果 |
|------|------|
| 移动方未过门闸 | **不** 登记遭遇；移动方 **退让** 至本郡最近己方城锚 + `road_client_notice`；本段行军 **提前结束**（已走格仍按 `stepsApplied` 扣粮）；退让锚不可解析 → **409** |
| 移动方过、守方未过 | **不** 登记遭遇；守方 **退让** 至本郡最近己方城锚 + `road_client_notice`；移动方 **继续** |
| 双方均过 | 登记 `road_encounters`（`fighting`），移动方落格，**丢弃** 本段后续路径；粮草按已走格重算 |
| 退让锚不可解析 | 整单 **409** |

| 其它 | 约定 |
|------|------|
| `gatekeeper_player_id` | 仅当格上守方 `road_intercept=1` 时写入 |
| 匪寨末步 | `targetPoiId` 为 `san_*_bandit_*` 的 **最后一道路格** **不** 登记遭遇、不因敌对 **409**（见 **17-7**） |

### 4.3 在线口径与「幽灵占格」

| 项 | 约定 |
|----|------|
| 在线阈值 | `max(players.last_active_at, accounts.lastActiveAt)` ≤ **5 分钟**（`DEFAULT_ONLINE_MS`） |
| `road-presence` | 仅绘制 **在线** 他人；与 `moveAlongRoad` 占格判定 **同一阈值** |
| 超时敌对 | 落脚前对 **离线** 同格敌对先 **`applyFactionPlayerRoadRetreat`**，避免「图上无人却 409」 |
| 僵死 `fighting` | 无 `battle_id` 且对手离线 → 可 **`resolveAbandonedRoadFightOnCellIfOpponentOffline`** 标 `resolved` |

### 4.4 叠放图坐标（颍川+汝南）

| 项 | 约定 |
|----|------|
| 世界格 → 写库 | `worldMapCellToPlayerRoad(gx, worldGy)` → `{ junId, gx, **gy** }`（`gy` 为郡内本地行，非 `localGy` 字段名） |
| 占格 SQL | `moveAlongRoad` 每步须用 `stepJun` + `stepPx` + **`stepPy = locStep.gy`** 查 `players.road_position_*`；误用 `locStep.localGy` 会导致 `y` 为 `undefined`、**永不登记遭遇** |

### 4.4 争空降（§5.1 同源）

两笔 `road/move` 串行：后到者遇 **非敌对** → 叠站；遇 **敌对** → 登记遭遇、截断（战斗链 **17-5**）。

---

## 5. 遭遇触发、锁格与战后地理

### 5.1 触发与外交

| 项 | 约定 |
|----|------|
| 几何 | **同一道路格**、双方 **敌对**、**均过开战门闸** → 登记遭遇 |
| M2 敌对 | `faction_id` **不同且均非空** 即互敌（外交实装后改读关系表） |

### 5.2 交战格锁

| 项 | 约定 |
|----|------|
| 登记后 | 该格 `road_encounters`；**非攻防双方** 不得将本格作为本段 **最后一步** 落脚点 |
| 过境 | 同请求内 **后续仍有道路步** 可 **过境** 不 409（`roadEncounterLockPassage.js`） |
| 寻路预览 | **不得** 为绕开遭遇而从 BFS 集合 **剔除** 敌对占格 |
| `fighting` 禁离 | 攻防双方在实例 `resolved` 前，路径 **离开交战格** → **409**（`fighting` 中不可 `targetPoiId` 入城规避） |

### 5.3 战后解锁（战略层）

| 项 | 约定 |
|----|------|
| API | `POST …/road/resolve-encounter` → `resolved`、`battle_id` |
| 守门战败 | `gatekeeper_player_id` 失利 → `road_intercept = 0` |
| 败方坐标 | **`applyFactionPlayerRoadRetreat`** + `road_client_notice`（与 §4.2 退让 **共用** `roadBattleRetreatPlacement.js`） |
| 再移动 | 解锁后敌对可再移入并 **再触发** 遭遇；非敌对可叠站 |

**战斗过程**（遇袭、观战、裁定、战报 `pvp_field`）→ **17-5** §5。

### 5.4 攻方遭遇 UI（2026-06-05）

| 项 | 约定 |
|----|------|
| 倒计时弹窗 | 登记遭遇后 **约 10s** 自动裁定；可点 **「立即开战」** 提前；弹窗内一并说明「服务端演算 → 直接进入战术对决回放并结算」 |
| 无中间层 | **不再** 单独弹出「道路裁定中」遮罩；倒计时结束/立即开战后 API 返回即挂 **`PvpTacticalBattleShell`** |
| 败方退让提示 | 战后 `road_client_notice` 仍在 **`applyFactionPlayerRoadRetreat`** 写入；客户端在 **战斗结算卡关闭后** 再弹「道路位置已调整」（含开启来战守方；见 **17-5** §5.2） |

---

## 6. 沿路行军粮草

| 项 | 数值 / 规则 |
|----|-------------|
| 每日免费格 | 前 **300** 格/日不扣粮（`roadConfig.FREE_MOVES_PER_DAY`） |
| 超出单价 | **2** 粮草/格 |
| 扣费顺序 | 先 `players.food`，不足则 **`faction_reserve` pool**（同事务） |
| 池日上限 | 自 pool 垫粮累计 ≤ **500**/日（**250** 格）（`road_reserve_date` / `road_reserve_used`） |
| 确认 | 请求须 **`confirmFoodCost: true`**，否则 400；UI 先预览净消耗 |
| 动画 | **单次** `POST`；前端跳跳棋 **150ms/格**（`MARCH_ANIM_MS_PER_STEP`，约 6.7 格/秒）；**视口居中跟随**本人 pawn；动画中锁选格 |

**设计意图**：抑制无目的乱走；与探索配额可并行（扣次顺序实装时再定）。

---

## 7. 行军目标：城心 / 匪寨（`targetPoiId`）

| 项 | 约定 |
|----|------|
| 可点选 | **本势力** 城池类（大/中/小城等；不含 fort/关隘）；本郡 **`san_*_bandit_*`** 匪寨 |
| 寻路 | 道路网上与对象中心 **沿路最短** 的合法道路格为道路终点，再 **一步** 入块 **几何中心** |
| 等长路 | 禁「先贴边再折向」；余下 **更靠内**、再 **更靠终点格**（`strategicMarchPoi.js`） |
| 离路坐标 | 库写 **占位矩形左上角**；绘制用 **块几何中心**（`resolveStrategicRecordedStandpointPx`） |
| 离路语义 | 站城心/匪寨 **不** 触发道路同格遭遇，直至再上路 |
| 0 步入城 | 已在邻接道路格时允许 `targetPoiId` + `confirmFoodCost`，**不扣** 沿路粮；`fighting` 本格仍 409 |
| 坐标种子 | `cities.position_x/y` 与 merged 一致；种子 NULL **不覆盖** 库内已有坐标（`import-city-geo-data.js`） |
| **空坐标语义** | 列值为 SQL **`NULL` / 未填** 时 **不得** 当作 `(0,0)`；footprint **回退** merged `cells` 按 `city_id` 解析（`collectStrategicPoiFootprint`）。实现：`dbCityAnchorCoordsFromRow`（`strategicMarchPoi.js`） |
| 预览与权威 | 有 `targetPoiId` 时 **扣粮步数、写库落点、动画 path** 均以服务端 `resolvedPath` + `poiAnchor` 为准；打开确认框前应 **`GET road/self`** 与档案路点对齐预览（`StrategicWorldMapSection`） |

### 7.1 复盘：许昌行军「预览 32 步、实走向左上角」(2026-06-05)

| 项 | 说明 |
|----|------|
| **现象** | 确认框显示至许昌约 **32** 道路步；确认后角色沿地图 **左缘北上**，落点 `(0,0)` 一带，刷新后弹 **「道路位置已调整」**（`NOTICE_JUN_COORD_FIXED`：颍川误记坐标实际落在汝南叠图行） |
| **直接根因** | `buildStrategicPoiFootprintFromDbCityRow` 对 `position_x/y = null` 误用 `Number(null) → 0`，在 **`city_medium` 可走 POI** 分支生成 **左上角 (0,0) 假城心**；`buildMarchPathToStrategicPoi` 因已有 footprint **不再** 回退 merged 格网，服务端寻路目标变为环颍关一带，**`poiAnchor` 亦为 (0,0)** |
| **为何仅预览正常** | 前端 `cityById` 常 **缺字段**（`positionX` 为 `undefined`）→ 走 cells 回退 → 许昌真占格 **(24,17)**；服务端 `SELECT … AS positionX` 得 **`null`** → 曾触发上述 bug |
| **数据侧** | 本地 `san_1`：**49** 城中 **仅 `san_1_city_2_xuchang`** 的 `position_x/y` 为 NULL（CSV 模板该列亦留空，见 **13-1 §3**）；其余城多已由管理端 **坐标入库** 写入库 |
| **代码修复** | `dbCityAnchorCoordsFromRow`：仅当列 **有值** 才解析坐标；否则与 merged `cells` 同源 footprint |
| **交互加固** | 打开/提交行军前 **`GET road/self`** 合并路点、提交前校验 `roadStandSnapshot`；修复 `setMarchConfirm(null)` 后仍读 `targetPoiId` 导致 **入城动画末帧** 未 `appendPoiSnap` 的问题 |
| **排查顺序（协作者）** | ① `cities.position_*` 是否 NULL ② 服务端 `road/move` 响应 `path.length` / `poiAnchor` 是否与预览一致 ③ `players.road_*` 是否与 `road/self` 一致 ④ 勿把档案修复弹窗当成「入城成功」 |

---

## 8. 大地图交互（浏览 vs 行军）

| 模式 | 进入 | 短按道路/城 |
|------|------|-------------|
| **浏览**（默认） | — | 城/寨：完整情报；操作按钮仅 **立于 POI** 时可用（`poiInteractionsLocked`） |
| **行军** | 本人 pawn「行军」/ 长按约 **980ms** / 道路格 **双击或双触** | 短按选目标 → `StrategicMarchMoveConfirm` → 确认后 `road/move` |

| 输入 | 本人 pawn |
|------|-----------|
| **道路格** | **行军** 固定于头像 **上方**、**来战/休战** 固定于 **下方**（始终可见，无弹出/关闭；点来战仍走扣银确认） |
| **叠放** | 本人 pawn **`z-index: 9`**，他人 **`z-index: 4`**；格网内 **先绘他人、后绘本人**（`WorldStrategicMapGrid`），道路上下邻格他人头像不得盖住本人 **行军/来战** 钮 |
| 城/寨/大本营等 **非道路格** | 键鼠单击 / 触摸短按弹出 **行军 + 来战** 操作条（无「关闭」；点空白收起） |
| 键鼠（道路/非道路） | 悬停 tooltip |
| 触摸 | 长按约 **980ms** 进入选目标（**无** 双击进军） |
| 道路格 | 仅 **可通行** 格：双击 / 双触直达确认框 |

取消确认或遮罩关闭 → **退出行军**。待增强：浏览模式下道路 **长按** 直达粮草确认。

---

## 9. 玩家标记与 `road-presence`

### 9.1 立点

| 状态 | 叠层锚点 |
|------|----------|
| 未上路 / 初态 | 主城块 **几何中心**（`main_city_id` ≠ 当前绘制格） |
| 道路上 | 当前 **道路格心** |
| 离路（城心/匪寨） | 对象块 **几何中心** |
| 离路（攻方大本营） | 大本营骨牌块 **几何中心**（须已拉取 `GET /api/pvp-wars` 中 `baseCamp`） |
| 路点解析依赖未就绪 | 底栏切走再回大地图会 **卸载并重挂** `WorldMap`：`cells` 常先于 **郡内城表**（`useStrategicCountyCityRuntime`）与 **PVP 大本营列表** 就绪。此窗口内 `resolveStrategicRecordedStandpointPx` 可能暂时得不到离路 POI，**不得**弹「路点与 POI 不同步」Toast；由 `isStrategicStandpointPoiDepsPending` 门闸至 `cityLoadState` / `pvpBaseCampsLoadState` 首包完成后再判定 |

### 9.2 他人与叠站条

| 项 | 约定 |
|----|------|
| 他人 | **仅在线** 出现在 `GET /api/cities/road-presence` 与绘制列表 |
| 同格多人 | 焦点 pawn + 右侧最多 **10** 个小头像（`buildStrategicRoadStackStripForFocal`） |
| 本人 | **始终** 绘制 |

---

## 10. API 索引

详版 → **[12-road-encounter-api](../../00/00-base/02-architecture-split/12-road-encounter-api.md)**（路径以 **02 §2.1.2** 为准）。

| 主题 | 方法 / 路径 |
|------|----------------|
| 守门 | `POST …/road/intercept`；`GET …/road/self` |
| 移动 | `POST …/road/move`（`path`、`confirmFoodCost`、`targetPoiId?`） |
| 战后解锁 | `POST …/road/resolve-encounter` |
| 郡内他人 | `GET /api/cities/road-presence` |
| 战斗相关 | 见 **12** §3、**17-5** §7 |

---

## 11. 实现落点

| 职责 | 主要文件 |
|------|----------|
| 道路服务聚合 | `backend/services/roadEncounterService.js`（战斗周期 + 权威推演；~870 行） |
| **沿路移动** `moveAlongRoad` | `backend/services/road/roadMoveAlongService.js`（~1020 行 · O3-A3） |
| 守门 / presence | `roadInterceptService.js`、`roadPresenceService.js` |
| 常量 / stale 清理 | `roadShared.js`、`roadStaleCleanup.js` |
| 道路配置 | `backend/config/roadConfig.js` |
| 退让锚格 | `backend/utils/roadBattleRetreatPlacement.js` |
| 锁格过境 | `shared/utils/roadEncounterLockPassage.js` |
| BFS / POI 路径 · profile 双读 | `shared/utils/strategicMarchPoi.js`（`playerRoadStandFromProfile`、`dbCityAnchorCoordsFromRow`） |
| Profile 出口 camelCase | `shared/utils/formatPlayerProfileApi` · `playerProfileService` |
| 在线判定 | `backend/utils/playerActivity.js` |
| 战略 UI | `StrategicWorldMapSection.jsx`（逐格回放 + 视口跟随）、`StrategicMarchMoveConfirm.jsx` |
| 格网与手势 | `WorldStrategicMapGrid.jsx`、`WorldStrategicMapTile.jsx`、`StrategicMapSelfPawn.jsx` |
| 立点像素 | `game/src/utils/strategicMapCityAnchor.js` |
| 前端路径预览 | `game/src/utils/strategicRoadMarchPath.js` |
| 战斗 UI（非行军） | `RoadEncounterDefenseRoot.jsx`、`WorldMap.jsx` → **17-5** |

---

## 12. 延后 / 开放项

| 项 | 说明 |
|----|------|
| 势力池玩法细则 | 捐献、权限 UI 与 **11-1** 对齐后补 |
| 道路格长按直达确认 | 已认可方向，未实装 |
| 跨郡 `road/move` | **31-2 §5.4** 待实装 |
| 分郡广播频率 | 压测后定标 |
| 交战态 pawn 描边 | 展示迭代 |

