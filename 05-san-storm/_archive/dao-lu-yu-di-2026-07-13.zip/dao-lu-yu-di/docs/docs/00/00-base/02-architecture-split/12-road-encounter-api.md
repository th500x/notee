# 架构 · 道路遭遇 API 契约

**文档版本**：v2.0.1  
**最后复盘**：2026-05-29  
**状态**：**已实装**

**战略玩法**（行军/占格/触发）：[31-6-STRATEGIC_ROAD_MARCH.md](../../30-frontend/31-6-STRATEGIC_ROAD_MARCH.md)  
**战斗推演**（与披挂同源 skirmish）：[17-5-DUEL_SYSTEM.md](../../10-core-system/17-5-DUEL_SYSTEM.md) §5  
**表结构**：[60-tables-other.md](../01-database-split/60-tables-other.md) §3.2.24  
**实现**：`roadEncounterService.js`（聚合 `services/road/*`：`roadMoveAlongService` · `roadInterceptService` · `roadPresenceService` · `roadShared` · `roadStaleCleanup`）  
**数值常量**：`backend/config/roadConfig.js`（门闸 50 银、垫粮日上限 500 等）

---

## 0. 通用约定

| 项 | 约定 |
|----|------|
| 前缀 | `/api/...`（生产可经 nginx 剥 `/api/san-storm`） |
| 鉴权 | `players` 路由下 `requireAuth` + `requireSelf('playerId')` |
| 成功 | `{ success: true, data: { … } }`（camelCase） |
| 失败 | `{ success: false, error, code? }` |
| 幂等 | `clientRequestId` 或 `Idempotency-Key`；重复请求返回首次结果；库内 `road_last_request_id` 按操作分域存储（`move:<id>` / `intercept:<id>`），避免多 Tab 交叉操作互相覆盖 |
| 限流 | `POST …/road/move` 约 5 次/秒 |
| 入参校验 | **`middleware/validationSchemas/playersRoad.js`**（O3-D1）；失败 `{ success:false, error, code:'VALIDATION_FAILED' }` |

---

## 1. 守门（`road_intercept`）

| 方法 | 路径 | 体 |
|------|------|-----|
| POST | `/api/players/:playerId/road/intercept` | `{ enable, clientRequestId? }` |
| GET | `/api/players/:playerId/road/self` | — |

开启拦截（0→1）扣 `players.silver` **50**。`road/self` 返回道路坐标、粮银、日累计垫粮/免费格等；**不**出参 `road_last_request_id`。

---

## 2. 沿路移动

| 方法 | 路径 | 体 |
|------|------|-----|
| POST | `/api/players/:playerId/road/move` | `season`, `junId`, `path[]`, `clientRequestId`, `confirmFoodCost: true`, `targetPoiId?` |

| 约束 | 说明 |
|------|------|
| `confirmFoodCost` | 必填 `true`，否则 400 |
| 权威路径 | 有 `targetPoiId` 或纯道路终点时服务端重算最短路；扣粮以**重算后** `path` 为准 |
| 实现 | **`road/roadMoveAlongService.moveAlongRoad`**（O3-A3）；聚合 export 仍为 **`roadEncounterService.moveAlongRoad`** |
| 扣粮顺序 | 先 `players.food`，不足自 **`faction_reserve`（pool）**；日累计 `road_reserve_used` 上限 500 |
| 占格 | `pending`/`fighting` 锁格；非参与方不得以交战格为**本段终点** |
| 进行中 | 攻防双方不得离开交战格直至 `resolved` |

---

## 3. 战斗与守方轮询

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `…/road/pending-encounter` | 守方遇袭摘要 |
| GET | `…/road/encounter-battle` | 攻方开战；`spectator=1` 守方观战 |
| POST | `…/road/encounter-authoritative-resolve` | 攻方权威推演（与披挂同源 skirmish） |
| GET | `…/road/encounter-authoritative-outcome` | 攻守轮询结果 JSON |
| POST | `…/road/encounter-battle-result` | 攻方 **客户端** `SmallMapBattle` 战后提交（`WorldMap` 道路分支） |
| POST | `…/road/resolve-encounter` | 战后解锁；仅实例攻防双方 |

`battle_type` 复用 **`pvp_field`**；详情写 `road_encounters.battle_id` → `battles`。

---

## 4. 郡内 presence（只读）

| 方法 | 路径 | Query |
|------|------|-------|
| GET | `/api/cities/road-presence` | `season`, `junId` |

返回他人在线道路坐标 + `lockedCells`。在线 = `playerActivity` 默认 5 分钟窗口。

---

## 5. 道路栅格数据源

| 优先级 | 来源 |
|--------|------|
| 1 | MySQL 已入库郡道路数据 |
| 2 | `public/data/worldmap/{jun}_merged.json` |

**单次请求内禁止混用**两种来源。

---

## 6. M2 外交

当前：`faction_id` 不同即敌对。后续改外交表时**只改服务端判定函数**，路径与请求体尽量不变。

---

## 7. 迁移

`create-road-encounters.sql`、`add-players-road-state.sql`、`add-players-road-client-notice.sql`、`road-encounters-add-authoritative-resolution-json.sql`（均在 `apply-pending-local-ddl.js`）。
